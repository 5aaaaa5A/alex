"""Nokov 动捕数据源封装。

- RealNokov: 基于任务书附录仓库 Nokov_python_bridge 的 ctypes 封装（树莓派上编译
  libnokov_pybridge.so 后使用）。桥的 python 端文件是 nokov_reader.py，
  通过 config["nokov_bridge_dir"] 指定所在目录。
- SimMocap: 无硬件仿真数据源，用于在 PC/树莓派上先跑通全部控制逻辑。

两个数据源都提供 latest_frame() -> MocapFrame | None（仅在出现新帧时返回）。
"""

import math
import os
import random
import sys
import time
import threading


class MocapFrame:
    """一帧动捕数据（与 Nokov_python_bridge 的 RigidBody 对齐）。"""

    __slots__ = (
        "frame_no", "recv_ts", "latency",
        "x_mm", "y_mm", "z_mm",
        "qx", "qy", "qz", "qw",
        "roll_deg", "pitch_deg", "yaw_deg",
        "mean_error",
    )

    def __init__(self):
        self.frame_no = 0
        self.recv_ts = 0.0
        self.latency = 0.0
        self.x_mm = 0.0
        self.y_mm = 0.0
        self.z_mm = 0.0
        self.qx = 0.0
        self.qy = 0.0
        self.qz = 0.0
        self.qw = 1.0
        self.roll_deg = 0.0
        self.pitch_deg = 0.0
        self.yaw_deg = 0.0
        self.mean_error = 0.0

    def valid(self):
        vals = (self.x_mm, self.y_mm, self.z_mm,
                self.qx, self.qy, self.qz, self.qw,
                self.roll_deg, self.pitch_deg, self.yaw_deg)
        if any(abs(v) >= 9000.0 for v in vals):
            return False
        return all(math.isfinite(v) and abs(v) < 1.0e5 for v in vals)

    def position_m(self):
        return (self.x_mm * 0.001, self.y_mm * 0.001, self.z_mm * 0.001)


class RealNokov:
    """包装 Nokov_python_bridge（nokov_reader.NokovClient）。"""

    def __init__(self, server_ip, rigid_body_id=None, bridge_dir=None):
        self.server_ip = server_ip
        self.rigid_body_id = rigid_body_id
        self.bridge_dir = bridge_dir
        self._client = None
        self._last_frame_no = -1
        self._lock = threading.Lock()

    def connect(self):
        if self.bridge_dir:
            d = os.path.expanduser(self.bridge_dir)
            if os.path.isdir(d) and d not in sys.path:
                sys.path.insert(0, d)
        try:
            from nokov_reader import NokovClient  # noqa: E402
        except ImportError as exc:
            raise RuntimeError(
                "找不到 nokov_reader.py（Nokov_python_bridge）。"
                "请在 config.json 的 nokov_bridge_dir 里填桥所在目录。"
            ) from exc

        self._client = NokovClient(self.server_ip)
        self._client.connect()
        return self

    def disconnect(self):
        if self._client is not None:
            try:
                self._client.disconnect()
            finally:
                self._client = None

    def latest_frame(self):
        """有新帧时返回 MocapFrame，否则返回 None。"""
        if self._client is None:
            return None
        result = self._client.latest()
        if result is None:
            return None
        info, bodies = result
        with self._lock:
            if info.frame_number <= self._last_frame_no:
                return None
            self._last_frame_no = info.frame_number

        body = None
        if self.rigid_body_id is not None:
            for b in bodies:
                if b.id == self.rigid_body_id:
                    body = b
                    break
        else:
            body = bodies[0] if bodies else None
        if body is None:
            return None

        f = MocapFrame()
        f.frame_no = info.frame_number
        f.recv_ts = time.time()
        f.latency = float(info.latency)
        f.x_mm, f.y_mm, f.z_mm = float(body.x), float(body.y), float(body.z)
        f.qx, f.qy, f.qz, f.qw = (float(body.qx), float(body.qy),
                                  float(body.qz), float(body.qw))
        if body.has_extend:
            f.roll_deg = float(body.roll)
            f.pitch_deg = float(body.pitch)
            f.yaw_deg = float(body.yaw)
        f.mean_error = float(body.mean_error)
        return f


class SimMocap:
    """仿真动捕：无人机位置以一阶惯性跟随 set_target，叠加噪声。

    偶尔注入丢帧/跳变，用于离线验证安全层。
    """

    def __init__(self, rate_hz=60.0, noise_mm=1.5, drop_prob=0.001,
                 jump_prob=0.0005, jump_mm=800.0, tau=0.25):
        self.rate_hz = rate_hz
        self.noise_mm = noise_mm
        self.drop_prob = drop_prob
        self.jump_prob = jump_prob
        self.jump_mm = jump_mm
        self.tau = tau
        self._x = 0.0
        self._y = 0.0
        self._z = 0.0
        self._tx = 0.0
        self._ty = 0.0
        self._tz = 0.0
        self._frame_no = 0
        self._last = None
        self._last_seen_no = -1
        self._stop = False
        self._lock = threading.Lock()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def connect(self):
        self._stop = False
        self._thread.start()
        return self

    def disconnect(self):
        self._stop = True
        self._thread.join(timeout=1.0)

    def set_target(self, x_m, y_m, z_m):
        with self._lock:
            self._tx, self._ty, self._tz = x_m, y_m, z_m

    def _run(self):
        period = 1.0 / self.rate_hz
        next_t = time.time()
        while not self._stop:
            with self._lock:
                a = 1.0 - math.exp(-period / self.tau)
                self._x += a * (self._tx - self._x)
                self._y += a * (self._ty - self._y)
                self._z += a * (self._tz - self._z)
                x, y, z = self._x, self._y, self._z
            self._frame_no += 1
            if random.uniform(0, 1) < self.drop_prob:
                continue  # 模拟丢帧：本帧不产生
            if random.uniform(0, 1) < self.jump_prob:
                x += self.jump_mm * 0.001  # 模拟定位跳变
            f = MocapFrame()
            f.frame_no = self._frame_no
            f.recv_ts = time.time()
            f.x_mm = x * 1000.0 + random.gauss(0, self.noise_mm)
            f.y_mm = y * 1000.0 + random.gauss(0, self.noise_mm)
            f.z_mm = z * 1000.0 + random.gauss(0, self.noise_mm)
            f.qw = 1.0
            f.yaw_deg = 0.0
            self._last = f
            next_t += period
            delay = next_t - time.time()
            if delay > 0:
                time.sleep(delay)

    def latest_frame(self):
        f = getattr(self, "_last", None)
        if f is None or f.frame_no <= self._last_seen_no:
            return None
        self._last_seen_no = f.frame_no
        return f


def make_source(cfg, sim=False):
    if sim:
        return SimMocap()
    return RealNokov(
        server_ip=cfg.get("nokov_server_ip", "192.168.5.6"),
        rigid_body_id=cfg.get("rigid_body_id"),
        bridge_dir=cfg.get("nokov_bridge_dir"),
    )

