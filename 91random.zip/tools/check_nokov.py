"""动捕数据质量检测：帧率、延迟、丢帧、静止噪声。

用法:  python3 tools/check_nokov.py --config config.json [--seconds 10] [--sim]
将无人机放静止，输出 x/y/z 标准差可直接用于 locSrv.extPosStdDev 参考。
"""

import argparse
import json
import math
import statistics
import sys
import time

sys.path.insert(0, ".")
sys.path.insert(0, "..")
import nokov_client  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--seconds", type=float, default=10.0)
    ap.add_argument("--sim", action="store_true")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    source = nokov_client.make_source(cfg, sim=args.sim)
    print("[mocap] connecting ...")
    source.connect()

    n = 0
    invalid_count = 0
    gaps = []
    lat = []
    xs, ys, zs = [], [], []
    t0 = time.time()
    last_no = None
    last_t = None
    try:
        while time.time() - t0 < args.seconds:
            f = source.latest_frame()
            if f is None:
                time.sleep(0.002)
                continue
            n += 1
            if last_no is not None and f.frame_no > last_no + 1:
                gaps.append(f.frame_no - last_no - 1)
            if last_t is not None:
                dt = f.recv_ts - last_t
            last_no, last_t = f.frame_no, f.recv_ts
            if not f.valid():
                invalid_count += 1
                continue
            lat.append(f.latency)
            xs.append(f.x_mm); ys.append(f.y_mm); zs.append(f.z_mm)
            if n % 20 == 0:
                print("\rframe=%d pos=(%.2f, %.2f, %.2f)mm yaw=%.1f"
                      % (f.frame_no, f.x_mm, f.y_mm, f.z_mm, f.yaw_deg),
                      end="")
    except KeyboardInterrupt:
        pass
    finally:
        source.disconnect()

    dur = time.time() - t0
    print("\n---- 统计 ----")
    print("时长 %.1fs, 帧数 %d, 平均帧率 %.1f Hz"
          % (dur, n, n / dur if dur else 0))
    if lat:
        print("延迟: mean=%.2fms max=%.2fms" %
              (statistics.mean(lat), max(lat)))
    if gaps:
        print("丢帧: 总缺口帧 %d, 次数 %d, 最大缺口 %d"
              % (sum(gaps), len(gaps), max(gaps)))
    else:
        print("丢帧: 0")
    print("无效帧: %d (Nokov 9999999/999999 等哨兵值)" % invalid_count)
    for name, arr in (("x", xs), ("y", ys), ("z", zs)):
        if len(arr) > 3:
            print("%s: mean=%.3fmm std=%.3fmm max-jump=%.1fmm"
                  % (name, statistics.mean(arr), statistics.stdev(arr),
                     max(abs(b - a) for a, b in zip(arr, arr[1:]))))
    print("建议: locSrv.extPosStdDev 取 (std/1000) 的 1~2 倍, 如 %.4f m"
          % (max(statistics.stdev(xs), statistics.stdev(ys),
                  statistics.stdev(zs)) / 1000.0 * 1.5
             if len(xs) > 3 else 0.01))


if __name__ == "__main__":
    main()
