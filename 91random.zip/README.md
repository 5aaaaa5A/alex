# crazyflie_mocap — Nokov 动捕 + Crazyflie 闭环飞行（树莓派）

任务书三个模块的核心代码骨架：
- 动捕数据接入（Nokov 桥，`nokov_client.py`）
- 坐标转换与异常处理（`transform.py`、`safety.py`）
- 闭环定点/轨迹飞行（`controller.py`、`crazyflie_link.py`）

## 1. 树莓派环境准备

```bash
# 本项目放到 ~/cf_mocap
cd ~/cf_mocap
bash pi_setup.sh
# 自动安装 g++/cflib、检查 SDK、编译动捕桥 libnokov_pybridge.so

# Crazyradio 接入（若还没做）
# 见 https://www.bitcraze.io/documentation/repository/crazyflie-lib-python/master/installation/usb_permissions/
```

> Nokov 官方 SDK（微信收到的压缩包）解压到 `~/XING_aarch64_SDK_4.1.0.5634`，
> 保证存在 `include/` 与 `lib/`；路径不同时用 `NOKOV_SDK_ROOT=... bash pi_setup.sh`。
> 更完整的逐步执行说明见项目根目录的 `详细执行步骤.md`。

## 2. 检查清单（先不飞，按顺序跑）

```bash
# 2.1 动捕数据质量（无人机放静止，需在实验室网络）
python3 tools/check_nokov.py --config config.json --seconds 10
# 关注：帧率 ≥50Hz、延迟 <30ms、静止 std 在 mm 级

# 2.2 Crazyflie 体检（不飞）
python3 tools/check_cf.py --uri radio://0/10/2M
# 确认 stabilizer.estimator=2、locSrv.extPosStdDev 存在、kalman.stateX/Y/Z 日志可用

# 2.3 坐标转换标定（手持无人机）
python3 tools/check_transform.py --config config.json
# 平移 0.5m 验证数值；旋转 90° 验证 yaw 与符号

# 2.4 无硬件逻辑自测（电脑上也能跑）
python3 main.py --sim --dry-run

# 2.5 数据分析（悬停RMS、轨迹/误差图、安全事件）
python3 tools/analyze_log.py
```

## 3. 飞行（务必 TA 在场）

```bash
# 地面模式：动捕→extpos→EKF，但不发送任何飞行指令（验证 EKF 收敛）
python3 main.py --config config.json

# 悬停（起飞 0.4m，爬升至 1.0m，悬停 5s 后自动降落）
python3 main.py --config config.json --flight --hover-only

# 矩形轨迹
python3 main.py --config config.json --flight --rect 0.6

# 圆形轨迹
python3 main.py --config config.json --flight --circle 0.5
```

飞行中按键：`空格` = 立即降落，`q` = 急停断油，`Ctrl+C` = 退出（先急停）。

## 4. 坐标系约定（报告要写）

- 无人机**上电时**把机头对准你定义的 CF 世界系 +X，并放在起飞点（原点）。
- `main.py` 默认用**第一帧动捕数据自动标定** origin 与 yaw_offset（`--no-auto-origin` 可改用 config.json 手填值）。
- 中途无人机重启 = EKF yaw 归零，必须重新摆放机头方向再标定。

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| `nokov_reader import 失败` | 确认 `config.json` 的 `nokov_bridge_dir` 指向含 `nokov_reader.py` 与 `libnokov_pybridge.so` 的目录 |
| `nokov_connect` 返回非 0 | ping 动捕服务器；确认服务器允许本机 IP；端口 3130/3131 |
| 连接 CF 失败 | `scan_interfaces()` 看接口；确认通道（多组飞行时问助教）；Crazyradio USB 权限 |
| EKF 不跟随动捕 | `stabilizer.estimator` 是否为 2；extpos 是否真的在发（看日志 `ekf_x` 与 `pos_x` 是否接近） |
| 起飞甩动 | 起飞前保持静止 3s 让 EKF 收敛；`locSrv.extPosStdDev` 按 check_nokov 的 std 调整 |
| 轨迹“斜着走” | 重启后 yaw 没重标定；检查机头摆放与 yaw 符号 |
| 遮挡后乱飞 | `safety.hold_time_s` 调小；确认 HOLD→LAND 链生效（看日志 status 列） |

## 6. 目录结构

```
config.json          参数（URI/动捕IP/标定/围栏/安全时限）
main.py              入口（模式开关、自动标定、键盘急停）
nokov_client.py      动捕数据源（真实桥 + 仿真）
transform.py         坐标转换
safety.py            异常剔除/保持/超时/围栏/低电量
controller.py        起飞/悬停/航点/降落状态机
crazyflie_link.py    CF 连接/参数/EKF 日志/extpos 线程
logger.py            CSV 日志
waypoint_gen.py      矩形/圆形轨迹生成
nokov_bridge/        Nokov_python_bridge（MIT, github.com/zhaohhhhah/Nokov_python_bridge）
tools/               check_nokov / check_cf / check_transform / analyze_log
pi_setup.sh          树莓派一键环境安装
logs/                实验 CSV（每个实验一个文件）
```

## 7. 免责声明

本骨架用于课程实验。真实飞行前请确认：电池电量、螺旋桨安装、通道占用、安全网、急停按键、TA 在场。

## v2 修复（漂移、启动过快、丢包）

- 起飞改为速度 ramp，高度到 0.30m 才进入 HOVER。
- 增加 `supervisor.send_arming_request(True)`、EKF 方差收敛等待和飞行前检查。
- 默认用 `send_extpose` 同时闭环位置/姿态，不兼容时自动退回 `send_extpos`。
- 降低 extpos/setpoint/日志频率，减少 Crazyradio 丢包。
- 如需低速率增强链路，可把 URI 改为 `radio://0/91/1M/E7E7E7E791`。
- 详见项目根目录 `部署修复_v2.md`。

## v3 修改（悬停高度与时间）

- `takeoff_z=0.4`：仅负责低速起飞，不会直接冲到 1m。
- 新增 `CLIMB` 状态：从 0.4m 平滑爬升到 `hover_z=1.0m`。
- `hover_hold_s=5`：在 1.0m 高度保持 5s 后自动降落。
- 悬停不再使用起飞高度，而是使用独立的 `hover_z`。
- `--rect/--circle` 的航点高度同步使用 `hover_z`，轨迹飞行也保持在 1.0m。
- 电池预检与空中保护阈值调整为 3.5V，给 1s 起飞电压跌落实例宽限（仍低于 3.5V 会强制降落）。
- 随机航点（统一 1.0m 高度）：`(0.5,0.2) → (0.1,0.8) → (-0.5,0.5) → (-0.3,-0.4) → (0,0)`。
- `max_altitude_m=1.45`：超过目标高度 0.45m 自动转降落，阻止持续上升。
