# -*- coding: utf-8 -*-
"""Reference trajectory generation for the host-side MPC.

The generator turns discrete waypoints into a smooth translation profile
with position, velocity and acceleration. A trapezoidal velocity profile
is used along the straight-line path of each segment.
"""

import math


class _Segment:
    def __init__(self, p0, p1, hold_s=0.0, vmax=0.8, amax=1.2):
        self.p0 = tuple(float(v) for v in p0)
        self.p1 = tuple(float(v) for v in p1)
        self.hold_s = max(0.0, float(hold_s))
        self.vmax = max(0.1, float(vmax))
        self.amax = max(0.05, float(amax))
        self.length = math.dist(self.p0, self.p1)
        self.dir = tuple((self.p1[i] - self.p0[i]) / self.length
                         for i in range(3)) if self.length > 1e-6 else (0.0, 0.0, 0.0)
        self.link_s = 0.0
        self.maneuver_s = 0.0
        self.total_s = 0.0
        self._plan()

    def _plan(self):
        if self.length < 1e-6:
            self.total_s = self.hold_s
            return
        v = self.vmax
        a = self.amax
        if self.length <= v * v / a:
            t1 = math.sqrt(self.length / a)
            self.link_s = 2.0 * t1
            self.maneuver_s = self.link_s
        else:
            t1 = v / a
            cruise = (self.length - v * v / a) / v
            self.link_s = 2.0 * t1 + cruise
            self.maneuver_s = self.link_s
        self.total_s = self.link_s + self.hold_s

    def sample(self, t):
        if t < 0.0:
            t = 0.0
        if t >= self.link_s:
            return self.p1, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
        if self.length < 1e-6:
            return self.p0, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
        v = self.vmax
        a = self.amax
        if self.length <= v * v / a:
            t1 = math.sqrt(self.length / a)
            if t < t1:
                s = 0.5 * a * t * t
                sp = a * t
                sa = a
            else:
                dt = t - t1
                s = 0.5 * a * t1 * t1 + a * t1 * dt - 0.5 * a * dt * dt
                sp = a * t1 - a * dt
                sa = -a
        else:
            t1 = v / a
            cruise = (self.length - v * v / a) / v
            t2 = t1 + cruise
            if t < t1:
                s = 0.5 * a * t * t
                sp = a * t
                sa = a
            elif t < t2:
                s = 0.5 * a * t1 * t1 + v * (t - t1)
                sp = v
                sa = 0.0
            else:
                dt = t - t2
                s = 0.5 * a * t1 * t1 + v * cruise + v * dt - 0.5 * a * dt * dt
                sp = v - a * dt
                sa = -a
        return (tuple(self.p0[i] + self.dir[i] * s for i in range(3)),
                tuple(self.dir[i] * sp for i in range(3)),
                tuple(self.dir[i] * sa for i in range(3)))


class ReferenceTrajectory:
    """Build a continuous translation trajectory from a waypoint list."""

    def __init__(self, waypoints=None, vmax=0.8, amax=1.2,
                 yaw_deg=0.0):
        self.waypoints = list(waypoints or [])
        self.vmax = float(vmax)
        self.amax = float(amax)
        self.yaw_deg = float(yaw_deg)
        self._segments = []
        self._starts = []
        self._total_s = 0.0
        self._started = False

    def start(self, current_pos, append_hold=True):
        if not self.waypoints:
            self._segments = [_Segment(current_pos, current_pos, 0.0,
                                       self.vmax, self.amax)]
        else:
            self._segments = []
            p_prev = tuple(current_pos)
            for wp in self.waypoints:
                p_next = (wp["x"], wp["y"], wp.get("z", 0.0))
                h = float(wp.get("hold_s", 0.0))
                if append_hold and wp is self.waypoints[-1]:
                    h = max(h, 0.0)
                self._segments.append(_Segment(p_prev, p_next, h,
                                               self.vmax, self.amax))
                p_prev = p_next
        self._starts = []
        t = 0.0
        for seg in self._segments:
            self._starts.append(t)
            t += seg.total_s
        self._total_s = t
        self._started = True

    @property
    def started(self):
        return self._started

    def sample(self, t):
        t = max(0.0, float(t))
        if not self._started:
            raise RuntimeError("ReferenceTrajectory.start() not called")
        if not self._segments:
            return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
        if t >= self._total_s:
            pos, vel, acc = self._segments[-1].sample(
                self._segments[-1].total_s)
            return pos, vel, acc
        for i, seg in enumerate(self._segments):
            t0 = self._starts[i]
            if t < t0 + seg.total_s or i == len(self._segments) - 1:
                pos, vel, acc = seg.sample(t - t0)
                return pos, vel, acc
        pos, vel, acc = self._segments[-1].sample(self._segments[-1].total_s)
        return pos, vel, acc
