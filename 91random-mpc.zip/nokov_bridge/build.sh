#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# 默认假设 SDK 在桥目录上一级；也可用 NOKOV_SDK_ROOT 指定
SDK_ROOT="${NOKOV_SDK_ROOT:-$(cd "$SCRIPT_DIR/.." && pwd)}"

if [ ! -f "$SDK_ROOT/include/NokovSDKClient.h" ] || [ ! -f "$SDK_ROOT/lib/libnokov_sdk.so" ]; then
  echo "找不到 Nokov SDK，请用环境变量指定:" >&2
  echo "  NOKOV_SDK_ROOT=~/XING_aarch64_SDK_4.1.0.5634 ./build.sh" >&2
  exit 1
fi

cd "$SCRIPT_DIR"

g++ \
  -D_LINUX \
  -std=c++17 \
  -O2 \
  -fPIC \
  -shared \
  nokov_bridge.cpp \
  -I"$SDK_ROOT/include" \
  -L"$SDK_ROOT/lib" \
  -lnokov_sdk \
  -pthread \
  -Wl,-rpath,"$SDK_ROOT/lib" \
  -o libnokov_pybridge.so

echo "Built: $SCRIPT_DIR/libnokov_pybridge.so"
ldd "$SCRIPT_DIR/libnokov_pybridge.so"
