# -*- coding: utf-8 -*-
"""Nokov motion state estimator for the host-side MPC.

The estimator fuses Nokov position (and extended velocity, when available)
with a constant-velocity Kalman filter. This gives the MPC a smooth state
vector [px, py, pz, vx, vy, vz] at a fixed control rate.
"""

import threading
import time

import numpy as np


class MocapStateEstimator:
    def __init__(self, rate_hz=50.0, pos_std_m=0.01, vel_std_mps=0.05,
                 use_mocap_velocity=True, max_jump_m=0.5,
                 mean_error_threshold=1.0):
        self.rate_hz = float(rate_hz)
        self.pos_std_m = float(pos_std_m)
        self.vel_std_mps = float(vel_std_mps)
        self.use_mocap_velocity = bool(use_mocap_velocity)
        self.max_jump_m = float(max_jump_m)
        self.mean_error_threshold = float(mean_error_threshold)

        self._lock = threading.Lock()
        self._x = np.zeros(6, dtype=float)
        self._P = np.eye(6, dtype=float) * 1.0
        self._yaw_deg = 0.0
        self._last_t = None
        self._last_pos = None
        self._frames = 0
        self._updates = 0
        self._rejected = 0
        self._vel_source = "none"
        self._initialized = False

    def reset(self, pos_m=(0.0, 0.0, 0.0), yaw_deg=0.0):
        with self._lock:
            self._x[:3] = pos_m
            self._x[3:] = 0.0
            self._P = np.eye(6, dtype=float) * 1.0
            self._yaw_deg = float(yaw_deg)
            self._last_t = None
            self._last_pos = None
            self._initialized = True

    def update(self, frame, pose_m, yaw_deg=0.0):
        if pose_m is None:
            return
        now = time.time()
        vel = None
        if getattr(frame, "has_extend", False) and self.use_mocap_velocity:
            vel = (frame.vx_mps, frame.vy_mps, frame.vz_mps)
        with self._lock:
            if self._last_pos is not None and self._initialized:
                dp = np.asarray(pose_m, dtype=float) - np.asarray(self._last_pos)
                if np.linalg.norm(dp) > self.max_jump_m:
                    self._rejected += 1
                    return
            if not self._initialized:
                self._x[:3] = pose_m
                self._x[3:] = 0.0
                self._P = np.eye(6, dtype=float) * 1.0
                self._yaw_deg = float(yaw_deg)
                self._initialized = True
            dt = 0.0
            if self._last_t is not None:
                dt = max(0.001, min(1.0, now - self._last_t))
            else:
                dt = 1.0 / max(1.0, self.rate_hz)
            self._last_t = now
            self._last_pos = tuple(float(v) for v in pose_m)
            self._frames += 1

            A = np.eye(6, dtype=float)
            A[0:3, 3:6] = np.eye(3) * dt
            q_pos = max(1e-8, (self.pos_std_m * 0.1) ** 2)
            q_vel = max(1e-6, (self.vel_std_mps * 0.15) ** 2)
            Q = np.diag([q_pos, q_pos, q_pos, q_vel, q_vel, q_vel])
            self._x = A @ self._x
            self._P = A @ self._P @ A.T + Q

            z_pos = np.asarray(pose_m, dtype=float)
            if vel is not None and all(np.isfinite(v) for v in vel):
                z = np.concatenate((z_pos, np.asarray(vel, dtype=float)))
                H = np.eye(6, dtype=float)
                R = np.diag([self.pos_std_m ** 2] * 3
                            + [self.vel_std_mps ** 2] * 3)
                self._vel_source = "mocap"
            else:
                z = z_pos
                H = np.zeros((3, 6), dtype=float)
                H[0:3, 0:3] = np.eye(3)
                R = np.eye(3) * max(1e-8, self.pos_std_m ** 2)
                self._vel_source = "kf"
            if not np.all(np.isfinite(z)):
                self._rejected += 1
                return
            S = H @ self._P @ H.T + R
            try:
                K = self._P @ H.T @ np.linalg.solve(S, np.eye(S.shape[0]))
            except np.linalg.LinAlgError:
                self._rejected += 1
                return
            innovation = z - H @ self._x
            self._x = self._x + K @ innovation
            self._P = (np.eye(6) - K @ H) @ self._P
            self._yaw_deg = float(yaw_deg)
            self._updates += 1

    def snapshot(self):
        with self._lock:
            return {
                "ready": self._initialized,
                "pos": tuple(float(v) for v in self._x[:3]),
                "vel": tuple(float(v) for v in self._x[3:6]),
                "yaw_deg": self._yaw_deg,
                "vel_source": self._vel_source,
                "frames": self._frames,
                "updates": self._updates,
                "rejected": self._rejected,
                "cov_diag": tuple(float(v) for v in np.diag(self._P)),
            }

    def state_vector(self):
        with self._lock:
            return np.array(self._x, dtype=float)
