# -*- coding: utf-8 -*-
"""CSV logger."""

import csv
import os
import time

FIELDS = [
    "ctrl_mode",
    "t_s",
    "frame_no", "mocap_ts", "latency",
    "raw_x_mm", "raw_y_mm", "raw_z_mm", "raw_yaw_deg",
    "pos_x", "pos_y", "pos_z", "pos_yaw_deg",
    "set_x", "set_y", "set_z", "set_yaw_deg",
    "err_x", "err_y", "err_z",
    "ekf_x", "ekf_y", "ekf_z", "ekf_err",
    "state_x", "state_y", "state_z",
    "state_vx", "state_vy", "state_vz",
    "state_vel_source",
    "ref_x", "ref_y", "ref_z",
    "ref_vx", "ref_vy", "ref_vz",
    "mpc_state_x", "mpc_state_y", "mpc_state_z",
    "mpc_ax", "mpc_ay", "mpc_az",
    "cmd_vx", "cmd_vy", "cmd_vz",
    "mpc_solve_ms", "mpc_cost", "mpc_backend",
    "mpc_fails", "cmd_saturated",
    "link_quality", "uplink_rssi",
    "extpose_mode", "extpose_sent", "extpose_errors",
    "battery_v", "status", "age_valid_s",
    "events",
]


class FlightLogger:
    def __init__(self, log_dir="logs", tag=""):
        os.makedirs(log_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        name = "%s_%s.csv" % (stamp, tag) if tag else "%s.csv" % stamp
        self.path = os.path.join(log_dir, name)
        self._f = open(self.path, "w", newline="", encoding="utf-8")
        self._w = csv.DictWriter(self._f, fieldnames=FIELDS)
        self._w.writeheader()
        self._f.flush()

    def write(self, row):
        r = {k: row.get(k, "") for k in FIELDS}
        self._w.writerow(r)
        self._f.flush()

    def close(self):
        if not self._f.closed:
            self._f.close()
