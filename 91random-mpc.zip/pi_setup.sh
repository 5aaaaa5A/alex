#!/usr/bin/env bash
set -euo pipefail

# Crazyflie + Nokov 树莓派一键环境安装（只做一次）
# 用法:  cd ~/cf_mocap && bash pi_setup.sh
# 前置:  本项目已在 ~/cf_mocap；SDK 已解压到 ~/XING_aarch64_SDK_4.1.0.5634

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK_ROOT="${NOKOV_SDK_ROOT:-$HOME/XING_aarch64_SDK_4.1.0.5634}"
BRIDGE_DIR="$PROJECT_ROOT/nokov_bridge"

echo "[1/6] 安装系统依赖 (g++/make/unzip/python3-pip)"
sudo apt-get update
sudo apt-get install -y g++ make unzip python3-pip

echo "[2/6] 安装 cflib"
pip3 install --upgrade cflib numpy osqp

echo "[3/6] 检查 Nokov SDK: $SDK_ROOT"
if [ ! -f "$SDK_ROOT/include/NokovSDKClient.h" ] || \
   [ ! -f "$SDK_ROOT/lib/libnokov_sdk.so" ]; then
  echo "错误: SDK 路径不对。请解压 SDK 到 ~/XING_aarch64_SDK_4.1.0.5634"
  echo "或重新运行: NOKOV_SDK_ROOT=~/你的SDK目录 bash pi_setup.sh"
  exit 1
fi
echo "   SDK OK"

echo "[4/6] 编译动捕桥 libnokov_pybridge.so"
cd "$BRIDGE_DIR"
NOKOV_SDK_ROOT="$SDK_ROOT" bash build.sh
ls -l libnokov_pybridge.so

echo "[5/6] 验证 cflib 可导入"
python3 -c "import cflib; print('   cflib OK')"

echo "[6/6] 检查 config.json"
cd "$PROJECT_ROOT"
python3 - <<'PY'
import json
cfg = json.load(open("config.json", encoding="utf-8"))
print("   radio_uri        =", cfg["radio_uri"])
print("   nokov_server_ip  =", cfg["nokov_server_ip"])
print("   rigid_body_id    =", cfg["rigid_body_id"])
print("   提示: 进场后确认航道路(通道)、动捕服务器IP、刚体ID")
PY

echo
echo "环境安装完成。下一步（实验室网络内按顺序执行）:"
echo "  1) python3 tools/check_nokov.py      # 动捕数据质量"
echo "  2) python3 tools/check_cf.py         # Crazyflie 参数体检"
echo "  3) python3 tools/check_transform.py  # 坐标标定"
echo "  4) python3 main.py                   # 地面模式(不发飞行指令)"
echo "  5) python3 main.py --flight --hover-only   # 首次悬停"
