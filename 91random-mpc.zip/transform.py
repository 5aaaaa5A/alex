# -*- coding: utf-8 -*-
"""Nokov world to Crazyflie world coordinate transform."""

import math


def wrap_180(deg):
    return ((deg + 180.0) % 360.0) - 180.0


def _normalize(q):
    n = math.sqrt(sum(v * v for v in q))
    if n < 1e-12:
        return (0.0, 0.0, 0.0, 1.0)
    return tuple(v / n for v in q)


def _mul(a, b):
    """Hamilton product, each quaternion is (w, x, y, z)."""
    a0, a1, a2, a3 = a
    b0, b1, b2, b3 = b
    return (
        a0 * b0 - a1 * b1 - a2 * b2 - a3 * b3,
        a0 * b1 + a1 * b0 + a2 * b3 - a3 * b2,
        a0 * b2 - a1 * b3 + a2 * b0 + a3 * b1,
        a0 * b3 + a1 * b2 - a2 * b1 + a3 * b0,
    )


class MocapToCF:
    def __init__(self, origin_mm=(0.0, 0.0, 0.0), yaw_offset_deg=0.0):
        self.set_origin(origin_mm, yaw_offset_deg)

    def set_origin(self, origin_mm, yaw_offset_deg=0.0):
        self.ox, self.oy, self.oz = origin_mm
        self.offset = yaw_offset_deg
        rad = math.radians(yaw_offset_deg)
        self._c = math.cos(rad)
        self._s = math.sin(rad)

    @property
    def origin_mm(self):
        return (self.ox, self.oy, self.oz)

    @property
    def yaw_offset_deg(self):
        return self.offset

    def position(self, x_mm, y_mm, z_mm):
        dx = x_mm * 0.001 - self.ox * 0.001
        dy = y_mm * 0.001 - self.oy * 0.001
        dz = z_mm * 0.001 - self.oz * 0.001
        x = self._c * dx + self._s * dy
        y = -self._s * dx + self._c * dy
        return (x, y, dz)

    def yaw(self, yaw_deg):
        return wrap_180(yaw_deg - self.offset)

    def quaternion(self, frame):
        """Transform Nokov body quaternion into the Crazyflie world frame."""
        qn = _normalize((frame.qw, frame.qx, frame.qy, frame.qz))
        half = math.radians(-self.offset) * 0.5
        qoff = (math.cos(half), 0.0, 0.0, math.sin(half))
        q = _mul(qoff, qn)
        return (q[1], q[2], q[3], q[0])

    def apply(self, frame):
        x, y, z = self.position(frame.x_mm, frame.y_mm, frame.z_mm)
        return {
            "x": x,
            "y": y,
            "z": z,
            "yaw_deg": self.yaw(frame.yaw_deg),
            "roll_deg": frame.roll_deg,
            "pitch_deg": frame.pitch_deg,
            "quaternion": self.quaternion(frame),
        }
