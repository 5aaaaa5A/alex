"""安全层：动捕异常处理 + 电子围栏 + 超时保护。

对应任务书 3-[4] 要求：
- 异常帧剔除（NaN / 位置跳变）
- 短时丢帧保持（HOLD：用上一有效位置继续闭环）
- 超时保护（LAND 降落 / ESTOP 断油）
- 电子围栏与低电量保护
"""

import math
import threading
import time
from collections import deque

OK = "OK"
HOLD = "HOLD"
LAND = "LAND"
ESTOP = "ESTOP"


class SafetyMonitor:
    def __init__(self, cfg):
        c = cfg or {}
        self.jump_limit_m = float(c.get("jump_limit_m", 0.5))
        self.jump_frames = int(c.get("jump_frames_before_loss", 3))
        self.hold_time_s = float(c.get("hold_time_s", 0.3))
        self.land_time_s = float(c.get("land_time_s", 1.0))
        self.estop_time_s = float(c.get("estop_time_s", 2.0))
        self.fence_x = float(c.get("geofence_x_m", 1.5))
        self.fence_y = float(c.get("geofence_y_m", 1.5))
        self.fence_z_min = float(c.get("geofence_z_min_m", 0.15))
        self.fence_z_max = float(c.get("geofence_z_max_m", 1.8))
        self.min_battery_v = float(c.get("min_battery_v", 3.6))
        self.battery_low_grace_s = float(c.get("battery_low_grace_s", 1.0))

        self._lock = threading.Lock()
        self._last_valid = (0.0, 0.0, 0.0)
        self._last_yaw = 0.0
        self._last_valid_t = time.time()
        self._last_frame_t = time.time()
        self._jump_count = 0
        self._first_jump_t = 0.0
        self._battery_v = None
        self._fence_active = False
        self._airborne = False
        self._airborne_since = None
        self._battery_low_active = False

        self.frames = 0
        self.invalid = 0
        self.jumps = 0
        self.drops = 0
        self.events = deque(maxlen=200)

    # ---------- 输入 ----------
    def on_frame(self, frame_ts, pose, yaw_deg=0.0, frame_no=0):
        """每个新动捕帧调用一次。pose 为 (x,y,z) m 或 None（非法帧）。"""
        with self._lock:
            self.frames += 1
            self._last_frame_t = frame_ts
            if pose is None or not all(math.isfinite(v) for v in pose):
                self.invalid += 1
                self._enter_jump(frame_ts)
                return
            x, y, z = pose
            if self.frames <= 1:
                self._accept(frame_ts, x, y, z, yaw_deg)
                return
            dx = x - self._last_valid[0]
            dy = y - self._last_valid[1]
            dz = z - self._last_valid[2]
            if math.sqrt(dx * dx + dy * dy + dz * dz) > self.jump_limit_m:
                self.jumps += 1
                self._enter_jump(frame_ts)
                return
            self._accept(frame_ts, x, y, z, yaw_deg)

    def _accept(self, t, x, y, z, yaw_deg):
        self._last_valid = (x, y, z)
        self._last_yaw = yaw_deg
        self._last_valid_t = t
        self._jump_count = 0
        self._first_jump_t = 0.0

    def _enter_jump(self, t):
        self._jump_count += 1
        if self._jump_count == 1:
            self._first_jump_t = t
        if self._jump_count >= self.jump_frames:
            # 连续异常：把“最后一次有效”的时刻回退到首次异常，触发 HOLD 计时
            self._last_valid_t = min(self._last_valid_t, self._first_jump_t)

    def set_battery(self, volts):
        with self._lock:
            self._battery_v = volts

    def set_fence_active(self, active):
        with self._lock:
            self._fence_active = bool(active)

    def set_airborne(self, airborne):
        with self._lock:
            active = bool(airborne)
            if active and not self._airborne:
                self._airborne_since = time.time()
                self._battery_low_active = False
            elif not active:
                self._airborne_since = None
                self._battery_low_active = False
            self._airborne = active

    def _log(self, msg):
        self.events.append((time.time(), msg))

    # ---------- 输出 ----------
    def evaluate(self, now=None):
        """控制循环每个周期调用。返回 (status, pose)。"""
        now = now if now is not None else time.time()
        with self._lock:
            status = OK
            age_frame = now - self._last_frame_t
            age_valid = now - self._last_valid_t
            if age_frame > self.estop_time_s:
                status = ESTOP
                self._log("ESTOP: no mocap frame for %.2fs" % age_frame)
            elif age_valid > self.estop_time_s:
                status = ESTOP
                self._log("ESTOP: no valid pose for %.2fs" % age_valid)
            elif age_valid > self.land_time_s:
                status = LAND
                self._log("LAND: pose lost for %.2fs" % age_valid)
            elif age_valid > self.hold_time_s:
                status = HOLD
                self._log("HOLD: pose stale for %.2fs" % age_valid)

            x, y, z = self._last_valid
            if self._fence_active and self._airborne:
                far = 1.5
                if (abs(x) > self.fence_x * far or abs(y) > self.fence_y * far
                        or z > self.fence_z_max * far):
                    status = ESTOP
                    self._log("ESTOP: far outside geofence (%.2f,%.2f,%.2f)"
                              % (x, y, z))
                elif (abs(x) > self.fence_x or abs(y) > self.fence_y
                        or z < self.fence_z_min or z > self.fence_z_max):
                    status = LAND
                    self._log("LAND: outside geofence (%.2f,%.2f,%.2f)"
                              % (x, y, z))

            if self._battery_v is not None and self._airborne:
                since = (now - self._airborne_since
                         if self._airborne_since is not None else 1e9)
                if (self._battery_v < self.min_battery_v
                        and since >= self.battery_low_grace_s):
                    if not self._battery_low_active:
                        self._battery_low_active = True
                        self._log("LAND: low battery %.2fV" % self._battery_v)
                    status = LAND
                elif self._battery_v >= self.min_battery_v:
                    self._battery_low_active = False
            return status, (x, y, z)

    def get_pose(self):
        with self._lock:
            return self._last_valid

    def get_yaw(self):
        with self._lock:
            return self._last_yaw

    def snapshot(self, now=None):
        now = now if now is not None else time.time()
        status, (x, y, z) = self.evaluate(now)
        with self._lock:
            return {
                "status": status,
                "x": x, "y": y, "z": z,
                "yaw_deg": self._last_yaw,
                "age_frame_s": round(now - self._last_frame_t, 3),
                "age_valid_s": round(now - self._last_valid_t, 3),
                "frames": self.frames,
                "invalid": self.invalid,
                "jumps": self.jumps,
                "battery_v": self._battery_v,
            }
