"""坐标转换标定/验证：手持无人机，实时显示 原始(mm) vs 转换后(m)。

用法:  python3 tools/check_transform.py --config config.json
流程:
  1) 无人机上电静止、机头指向实验台选定的 CF 世界系 +X；
  2) 启动本工具（默认用首帧自动标定 origin/yaw_offset）；
  3) 沿动捕 X 方向平移 0.5m：pos_x 应 +0.5（±5mm），pos_y 基本不变；
  4) 原地顺时针转 90°：pos_yaw_deg 应 -90（±2°，符号不对就在 config 里改标定）；
  5) 按 Ctrl+C 结束。
"""

import argparse
import csv
import json
import sys
import time

sys.path.insert(0, ".")
sys.path.insert(0, "..")
import nokov_client  # noqa: E402
import transform as tf  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--no-auto-origin", action="store_true")
    ap.add_argument("--out", default="logs/transform_check.csv")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    source = nokov_client.make_source(cfg, sim=args.sim)
    source.connect()

    first = None
    while first is None:
        f = source.latest_frame()
        if f is not None and f.valid():
            first = f
        else:
            time.sleep(0.01)

    if args.no_auto_origin:
        t = tf.MocapToCF(tuple(cfg["origin"]), cfg["yaw_offset_deg"])
    else:
        t = tf.MocapToCF((first.x_mm, first.y_mm, first.z_mm), first.yaw_deg)
        print("自动标定 origin=(%.2f,%.2f,%.2f)mm yaw_offset=%.2fdeg"
              % (first.x_mm, first.y_mm, first.z_mm, first.yaw_deg))

    import os
    os.makedirs("logs", exist_ok=True)
    out = open(args.out, "w", newline="", encoding="utf-8")
    w = csv.writer(out)
    w.writerow(["t", "raw_x_mm", "raw_y_mm", "raw_z_mm", "raw_yaw_deg",
                "x_m", "y_m", "z_m", "yaw_deg"])
    print("t       raw(mm)                      ->  cf(m)              yaw")
    try:
        while True:
            f = source.latest_frame()
            if f is None or not f.valid():
                time.sleep(0.01)
                continue
            p = t.apply(f)
            w.writerow([round(time.time(), 3), f.x_mm, f.y_mm, f.z_mm,
                        f.yaw_deg, round(p["x"], 4), round(p["y"], 4),
                        round(p["z"], 4), round(p["yaw_deg"], 2)])
            print("%8.1f (%8.1f,%8.1f,%7.1f) yaw=%6.1f -> (%+.3f,%+.3f,%+.3f) yaw=%+6.1f"
                  % (time.time(), f.x_mm, f.y_mm, f.z_mm, f.yaw_deg,
                     p["x"], p["y"], p["z"], p["yaw_deg"]))
            time.sleep(0.3)
    except KeyboardInterrupt:
        pass
    finally:
        out.close()
        source.disconnect()
        print("saved:", args.out)


if __name__ == "__main__":
    main()
