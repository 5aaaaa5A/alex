# -*- coding: utf-8 -*-
"""Compare official SDK and MPC flight logs and render comparison figures.

Usage:
  python3 tools/compare_logs.py --official logs/official.csv --mpc logs/mpc.csv
  python3 tools/compare_logs.py --official ... --mpc ... \
      --phase HOVER,WAYPOINTS --plot-dir outputs --out outputs/summary.csv

Outputs:
  - Console phase statistics.
  - official_vs_mpc_trajectory.png
  - official_vs_mpc_errors.png
  - official_vs_mpc_speed.png
  - official_vs_mpc_mpc_metrics.png
  - official_vs_mpc_rms.png
  - With --out: machine-readable summary CSV.
"""

import argparse
import csv
import json
import math
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from trajectory_gen import ReferenceTrajectory
except ImportError:
    ReferenceTrajectory = None


def fnum(v):
    try:
        if v is None or str(v).strip() == "":
            return None
        return float(v)
    except (TypeError, ValueError):
        return None


def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_config(path):
    if not path or not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def phase_rows(rows, phase):
    phase = phase.upper()
    return [r for r in rows
            if (r.get("status") or "").split("/")[-1].upper() == phase]


def col_values(rows, col):
    out = []
    for r in rows:
        v = fnum(r.get(col))
        if v is not None:
            out.append(v)
    return out


def axis_stats(rows, axis):
    vals = col_values(rows, "err_" + axis)
    if not vals:
        return None
    return {
        "mean": statistics.mean(vals),
        "rms": math.sqrt(statistics.mean(v * v for v in vals)),
        "max": max(abs(v) for v in vals),
        "std": statistics.stdev(vals) if len(vals) > 1 else 0.0,
        "n": len(vals),
    }


def phase_stats(rows, phases):
    out = {}
    for phase in phases:
        rs = phase_rows(rows, phase)
        out[phase] = {a: axis_stats(rs, a) for a in ("x", "y", "z")}
    return out


def stats_from_values(vals):
    if not vals:
        return None
    return {
        "mean": statistics.mean(vals),
        "rms": math.sqrt(statistics.mean(v * v for v in vals)),
        "max": max(abs(v) for v in vals),
        "std": statistics.stdev(vals) if len(vals) > 1 else 0.0,
        "n": len(vals),
    }


def make_reference(cfg, start_pos):
    m = cfg.get("mpc", {})
    vmax = float(m.get("vmax_xy", 0.8))
    amax = float(m.get("amax_xy", 1.2))
    vmax_z = float(m.get("vmax_z", 0.4))
    amax_z = float(m.get("amax_z", 0.8))
    tr = ReferenceTrajectory(
        cfg.get("waypoints", []), vmax=vmax, amax=amax,
        vmax_axis=(vmax, vmax, vmax_z),
        amax_axis=(amax, amax, amax_z))
    tr.start(start_pos)
    return tr


def logged_ref_error(r):
    t = fnum(r.get("t_s"))
    px, py, pz = (fnum(r.get("pos_" + a)) for a in "xyz")
    rx, ry, rz = (fnum(r.get("ref_" + a)) for a in "xyz")
    if rx is None or ry is None or rz is None:
        rx, ry, rz = (fnum(r.get("set_" + a)) for a in "xyz")
    if None not in (t, px, py, pz, rx, ry, rz):
        return t, (px - rx, py - ry, pz - rz)
    return None


def trajectory_errors(rows, phase, cfg):
    rs = phase_rows(rows, phase)
    if not rs:
        return []
    if phase == "WAYPOINTS" and cfg.get("waypoints") and ReferenceTrajectory:
        first = rs[0]
        start = tuple(fnum(first.get("pos_" + a)) for a in "xyz")
        t0 = fnum(first.get("t_s"))
        if None not in start and t0 is not None:
            tr = make_reference(cfg, start)
            out = []
            for r in rs:
                t = fnum(r.get("t_s"))
                pos = tuple(fnum(r.get("pos_" + a)) for a in "xyz")
                if t is None or None in pos:
                    continue
                ref = tr.sample(t - t0)[0]
                out.append((t, tuple(pos[i] - ref[i] for i in range(3))))
            return out
    out = []
    for r in rs:
        err = logged_ref_error(r)
        if err:
            out.append(err)
    return out


def trajectory_stats(rows, phases, cfg):
    out = {}
    for phase in phases:
        errs = trajectory_errors(rows, phase, cfg)
        out[phase] = {}
        for axis in "xyz":
            vals = [e[1]["xyz".index(axis)] for e in errs]
            out[phase][axis] = stats_from_values(vals)
    return out


def duration_s(rows):
    vals = col_values(rows, "t_s")
    return (vals[-1] - vals[0]) if vals else 0.0


def print_stats(label, rows):
    print("== %s  (n=%d) ==" % (label, len(rows)))
    for axis in ("x", "y", "z"):
        s = axis_stats(rows, axis)
        if s:
            print("  %s: mean=%+.3fcm rms=%.3fcm max=%.3fcm std=%.3fcm"
                  % (axis.upper(), s["mean"] * 100, s["rms"] * 100,
                     s["max"] * 100, s["std"] * 100))
    mpc = [r for r in rows if str(r.get("ctrl_mode") or "").startswith("mpc")]
    if mpc:
        solve = col_values(mpc, "mpc_solve_ms")
        if solve:
            print("  mpc_solve_ms: mean=%.2f max=%.2f"
                  % (statistics.mean(solve), max(solve)))
        fails = [int(r.get("mpc_fails") or 0) for r in mpc]
        print("  mpc_fails(max) = %s" % (max(fails) if fails else 0))


def print_summary(off_rows, mpc_rows, phases):
    print("\n== Run ==")
    print("official duration %.1fs rows %d" % (duration_s(off_rows),
                                               len(off_rows)))
    print("mpc duration %.1fs rows %d" % (duration_s(mpc_rows),
                                          len(mpc_rows)))
    for phase in phases:
        print_stats("official/" + phase, phase_rows(off_rows, phase))
        print_stats("mpc/" + phase, phase_rows(mpc_rows, phase))


def print_traj_phase(label, rows, phase, cfg):
    errs = trajectory_errors(rows, phase, cfg)
    print("== %s/trajectory  (n=%d) ==" % (label, len(errs)))
    for axis in "xyz":
        vals = [e[1]["xyz".index(axis)] for e in errs]
        s = stats_from_values(vals)
        if s:
            print("  %s: mean=%+.3fcm rms=%.3fcm max=%.3fcm std=%.3fcm"
                  % (axis.upper(), s["mean"] * 100, s["rms"] * 100,
                     s["max"] * 100, s["std"] * 100))


def print_traj_summary(off_rows, mpc_rows, phases, cfg):
    print("\n== Unified smooth-reference trajectory error ==")
    for phase in phases:
        print_traj_phase("official/" + phase, off_rows, phase, cfg)
        print_traj_phase("mpc/" + phase, mpc_rows, phase, cfg)


def series_xy(rows, ref_kind="logged"):
    xs, ys = [], []
    for r in rows:
        if ref_kind == "logged":
            x = fnum(r.get("ref_x"))
            y = fnum(r.get("ref_y"))
            if x is None or y is None:
                x = fnum(r.get("set_x"))
                y = fnum(r.get("set_y"))
        else:
            x = fnum(r.get("set_x"))
            y = fnum(r.get("set_y"))
        px = fnum(r.get("pos_x"))
        py = fnum(r.get("pos_y"))
        if None not in (x, y, px, py):
            xs.append((x, y))
            ys.append((px, py))
    return xs, ys


def plot_trajectory(off_rows, mpc_rows, waypoints, cfg, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 6))
    if ReferenceTrajectory and cfg.get("waypoints"):
        tr = make_reference(cfg, (0.0, 0.0, float(cfg.get("hover_z", 1.0))))
        ts = [i * 0.05 for i in range(int(tr._total_s / 0.05) + 2)]
        pts = [tr.sample(t)[0] for t in ts]
        ax.plot([p[0] for p in pts], [p[1] for p in pts],
                color="0.45", ls="--", lw=1.2,
                label="Unified smooth reference")
    for rows, color, label in ((off_rows, "tab:blue", "Official actual"),
                               (mpc_rows, "tab:red", "MPC actual")):
        xs = [fnum(r.get("pos_x")) for r in rows]
        ys = [fnum(r.get("pos_y")) for r in rows]
        pts = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
        if pts:
            ax.plot([p[0] for p in pts], [p[1] for p in pts],
                    color=color, lw=1.0, label=label)
    if waypoints:
        ax.scatter([w["x"] for w in waypoints],
                   [w["y"] for w in waypoints],
                   marker="o", s=24, facecolor="none",
                   edgecolor="k", label="Waypoints")
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_title("XY path vs unified smooth reference")
    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    print("[plot] %s" % path)


def mpc_ref_error(rows):
    out = []
    for r in rows:
        t = fnum(r.get("t_s"))
        px, py, pz = (fnum(r.get("pos_" + a)) for a in "xyz")
        rx, ry, rz = (fnum(r.get("ref_" + a)) for a in "xyz")
        if None not in (t, px, py, pz, rx, ry, rz):
            out.append((t, (px - rx, py - ry, pz - rz)))
    return out


def plot_errors(off_rows, mpc_rows, cfg, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(3, 1, figsize=(9, 7), sharex=True)
    off_traj = (trajectory_errors(off_rows, "HOVER", cfg)
                + trajectory_errors(off_rows, "WAYPOINTS", cfg))
    mpc_traj = (trajectory_errors(mpc_rows, "HOVER", cfg)
                + trajectory_errors(mpc_rows, "WAYPOINTS", cfg))
    for ax, axis, label in zip(axes, "xyz", ("X", "Y", "Z")):
        for data, color, ls, curve_label in (
                (off_traj, "tab:blue", "-", "Official trajectory error"),
                (mpc_traj, "tab:red", "-", "MPC trajectory error")):
            if data:
                ax.plot([v[0] for v in data],
                        [v[1]["xyz".index(axis)] * 100 for v in data],
                        color=color, ls=ls, lw=1.0, label=curve_label)
        ax.set_ylabel("%s error (cm)" % label)
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best", fontsize=7)
    axes[-1].set_xlabel("t (s)")
    fig.suptitle("Tracking error vs unified smooth reference")
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(path, dpi=160)
    plt.close(fig)
    print("[plot] %s" % path)


def plot_speed(off_rows, mpc_rows, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    def speed_series(rows):
        vals = []
        for r in rows:
            vx, vy, vz = (fnum(r.get("state_" + a)) for a in "xyz")
            t = fnum(r.get("t_s"))
            if None not in (t, vx, vy, vz):
                vals.append((t, math.sqrt(vx * vx + vy * vy + vz * vz)))
        return vals

    fig, ax = plt.subplots(figsize=(9, 3.4))
    for rows, color, label in ((off_rows, "tab:blue", "Official"),
                               (mpc_rows, "tab:red", "MPC")):
        vals = speed_series(rows)
        if vals:
            ax.plot([v[0] for v in vals], [v[1] for v in vals],
                    color=color, lw=1.0, label=label)
    ax.set_xlabel("t (s)")
    ax.set_ylabel("estimated speed (m/s)")
    ax.set_title("Estimated inertial speed")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    print("[plot] %s" % path)


def plot_mpc_metrics(mpc_rows, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = [r for r in mpc_rows
            if fnum(r.get("cmd_vx")) is not None
            and fnum(r.get("mpc_solve_ms")) is not None]
    if not rows:
        print("[plot] no MPC solve rows, skip mpc_metrics")
        return
    t = col_values(rows, "t_s")
    cmd = {a: col_values(rows, "cmd_v" + a) for a in "xyz"}
    acc = {a: col_values(rows, "mpc_a" + a) for a in "xyz"}
    solve = col_values(rows, "mpc_solve_ms")
    sat = col_values(rows, "cmd_saturated")
    fig, axes = plt.subplots(3, 1, figsize=(9, 7), sharex=True)
    for a, axis in zip("xyz", ("X", "Y", "Z")):
        axes[0].plot(t, cmd[a], lw=0.9, label="v_%s" % axis)
        axes[1].plot(t, acc[a], lw=0.9, label="a_%s" % axis)
    axes[0].set_ylabel("velocity cmd (m/s)")
    axes[1].set_ylabel("MPC accel (m/s^2)")
    axes[2].plot(t, solve, color="tab:purple", lw=0.9)
    axes[2].set_ylabel("solve time (ms)")
    if sat:
        axes[2].scatter(t, [s * max(solve) for s in sat], s=4,
                        color="r", label="saturated")
    axes[0].legend(fontsize=7, ncol=3)
    axes[1].legend(fontsize=7, ncol=3)
    axes[2].legend(fontsize=7)
    axes[2].set_xlabel("t (s)")
    for ax in axes:
        ax.grid(True, alpha=0.3)
    fig.suptitle("MPC control signals and solver time")
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(path, dpi=160)
    plt.close(fig)
    print("[plot] %s" % path)


def plot_rms(off_stats, mpc_stats, phases, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4))
    labels = []
    x = []
    off_vals = []
    mpc_vals = []
    idx = 0
    for phase in phases:
        for axis in "xyz":
            labels.append("%s/%s" % (phase, axis.upper()))
            x.append(idx)
            os_ = off_stats.get(phase, {}).get(axis)
            ms_ = mpc_stats.get(phase, {}).get(axis)
            off_vals.append(os_["rms"] * 100 if os_ else 0.0)
            mpc_vals.append(ms_["rms"] * 100 if ms_ else 0.0)
            idx += 1
    width = 0.36
    ax.bar([v - width / 2 for v in x], off_vals, width,
           label="Official", color="tab:blue")
    ax.bar([v + width / 2 for v in x], mpc_vals, width,
           label="MPC", color="tab:red")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=7)
    ax.set_ylabel("RMS error (cm)")
    ax.set_title("Trajectory tracking RMS: official SDK vs host MPC")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    print("[plot] %s" % path)


def write_summary(path, off_rows, mpc_rows, off_stats, mpc_stats,
                  off_traj_stats, mpc_traj_stats, phases, cfg, mpc_solve,
                  mpc_fails):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["section", "phase", "mode", "axis", "metric", "value",
                    "unit"])
        for section, off, mpc in (
                ("position-error", off_stats, mpc_stats),
                ("trajectory-error", off_traj_stats, mpc_traj_stats)):
            for phase in phases:
                for mode, stats in (("official", off), ("mpc", mpc)):
                    for axis in "xyz":
                        s = stats.get(phase, {}).get(axis)
                        if not s:
                            continue
                        w.writerow([section, phase, mode, axis,
                                    "mean", round(s["mean"], 6), "m"])
                        w.writerow([section, phase, mode, axis,
                                    "rms", round(s["rms"], 6), "m"])
                        w.writerow([section, phase, mode, axis,
                                    "max", round(s["max"], 6), "m"])
                        w.writerow([section, phase, mode, axis,
                                    "std", round(s["std"], 6), "m"])
                        w.writerow([section, phase, mode, axis,
                                    "n", s["n"], "samples"])
        for phase in phases:
            for mode, rows in (("official", off_rows), ("mpc", mpc_rows)):
                errs = trajectory_errors(rows, phase, cfg)
                norms = [math.sqrt(sum(v * v for v in e[1])) for e in errs]
                s = stats_from_values(norms)
                if s:
                    w.writerow(["trajectory-error", phase, mode, "3d",
                                "mean", round(s["mean"], 6), "m"])
                    w.writerow(["trajectory-error", phase, mode, "3d",
                                "rms", round(s["rms"], 6), "m"])
                    w.writerow(["trajectory-error", phase, mode, "3d",
                                "max", round(s["max"], 6), "m"])
        w.writerow(["run", "", "official", "", "duration_s",
                    round(duration_s(off_rows), 3), "s"])
        w.writerow(["run", "", "official", "", "rows", len(off_rows),
                    "samples"])
        w.writerow(["run", "", "mpc", "", "duration_s",
                    round(duration_s(mpc_rows), 3), "s"])
        w.writerow(["run", "", "mpc", "", "rows", len(mpc_rows),
                    "samples"])
        if mpc_solve:
            w.writerow(["mpc", "", "mpc", "", "solve_mean_ms",
                        round(statistics.mean(mpc_solve), 3), "ms"])
            w.writerow(["mpc", "", "mpc", "", "solve_max_ms",
                        round(max(mpc_solve), 3), "ms"])
        w.writerow(["mpc", "", "mpc", "", "fails_max", mpc_fails,
                    "count"])
    print("[out] %s" % path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--official", required=True)
    ap.add_argument("--mpc", required=True)
    ap.add_argument("--phase", default="HOVER,WAYPOINTS")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--out", default="")
    ap.add_argument("--plot-dir", default="")
    args = ap.parse_args()

    phases = [p.strip().upper() for p in args.phase.split(",") if p.strip()]
    if not phases:
        phases = ["HOVER", "WAYPOINTS"]

    off_rows = load_csv(args.official)
    mpc_rows = load_csv(args.mpc)
    cfg = load_config(args.config)
    waypoints = cfg.get("waypoints", [])
    off_stats = phase_stats(off_rows, phases)
    mpc_stats = phase_stats(mpc_rows, phases)
    off_traj_stats = trajectory_stats(off_rows, phases, cfg)
    mpc_traj_stats = trajectory_stats(mpc_rows, phases, cfg)

    print_summary(off_rows, mpc_rows, phases)
    print_traj_summary(off_rows, mpc_rows, phases, cfg)

    mpc_ctrl = [r for r in mpc_rows
                if fnum(r.get("cmd_vx")) is not None
                and fnum(r.get("mpc_solve_ms")) is not None]
    mpc_solve = col_values(mpc_ctrl, "mpc_solve_ms")
    mpc_fails = max([int(r.get("mpc_fails") or 0) for r in mpc_ctrl],
                    default=0)

    out_dir = args.plot_dir or os.path.dirname(args.official)
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.join(out_dir, "official_vs_mpc")
    plot_trajectory(off_rows, mpc_rows, waypoints, cfg,
                    base + "_trajectory.png")
    plot_errors(off_rows, mpc_rows, cfg, base + "_errors.png")
    plot_speed(off_rows, mpc_rows, base + "_speed.png")
    plot_rms(off_traj_stats, mpc_traj_stats, phases, base + "_rms.png")
    plot_mpc_metrics(mpc_rows, base + "_mpc_metrics.png")

    if args.out:
        write_summary(args.out, off_rows, mpc_rows, off_stats, mpc_stats,
                      off_traj_stats, mpc_traj_stats, phases, cfg, mpc_solve,
                      mpc_fails)
    return 0


if __name__ == "__main__":
    sys.exit(main())
