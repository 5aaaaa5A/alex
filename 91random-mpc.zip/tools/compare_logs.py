# -*- coding: utf-8 -*-
"""Compare official SDK and MPC flight logs for the same mission phase.

Usage:
  python3 tools/compare_logs.py --official logs/a_official.csv --mpc logs/b_mpc.csv
  python3 tools/compare_logs.py --official ... --mpc ... --out logs/summary.csv
"""

import argparse
import csv
import math
import statistics
import sys


def fnum(v):
    try:
        if v is None or v == "":
            return None
        return float(v)
    except (TypeError, ValueError):
        return None


def rows_for(rows, phase):
    return [r for r in rows if r.get("status", "").split("/")[-1] == phase]


def axis_stats(rows, axis):
    vals = [fnum(r.get("err_" + axis)) for r in rows]
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    return {
        "mean": statistics.mean(vals),
        "rms": math.sqrt(statistics.mean(v * v for v in vals)),
        "max": max(abs(v) for v in vals),
        "std": statistics.stdev(vals) if len(vals) > 1 else 0.0,
    }


def print_stats(label, rows):
    print("== %s  (n=%d) ==" % (label, len(rows)))
    for axis in ("x", "y", "z"):
        s = axis_stats(rows, axis)
        if s:
            print("  %s: mean=%+.3fcm rms=%.3fcm max=%.3fcm std=%.3fcm"
                  % (axis.upper(), s["mean"] * 100, s["rms"] * 100,
                     s["max"] * 100, s["std"] * 100))
    mpc = [r for r in rows if (r.get("ctrl_mode") or "").startswith("mpc")]
    if mpc:
        solve = [fnum(r.get("mpc_solve_ms")) for r in mpc]
        solve = [v for v in solve if v is not None]
        if solve:
            print("  mpc_solve_ms: mean=%.2f max=%.2f"
                  % (statistics.mean(solve), max(solve)))
        print("  mpc_fails(max) = %s"
              % max(int(r.get("mpc_fails") or 0) for r in mpc))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--official", required=True)
    ap.add_argument("--mpc", required=True)
    ap.add_argument("--phase", default="HOVER")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    def load(path):
        with open(path, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    off = rows_for(load(args.official), args.phase)
    mpc = rows_for(load(args.mpc), args.phase)
    print_stats("official/" + args.phase, off)
    print_stats("mpc/" + args.phase, mpc)

    if args.out:
        with open(args.out, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["phase", "mode", "axis", "mean_m", "rms_m", "max_m"])
            for label, rows in (("official", off), ("mpc", mpc)):
                for axis in ("x", "y", "z"):
                    s = axis_stats(rows, axis)
                    if s:
                        w.writerow([args.phase, label, axis,
                                    round(s["mean"], 4), round(s["rms"], 4),
                                    round(s["max"], 4)])
        print("[out] %s" % args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
