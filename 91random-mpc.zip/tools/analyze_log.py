"""实验日志分析：分阶段误差统计 + 轨迹对比图 + 安全事件汇总（报告素材）。

用法:
  python3 tools/analyze_log.py logs/20260904_153000_square.csv
  python3 tools/analyze_log.py                # 默认分析 logs/ 下最新的 CSV
输出:
  - 控制台统计（悬停/航点阶段的平均、RMS、最大误差）
  - 图片: <csv同目录>/figures/<csv名>_trajectory.png / _errors.png（需要 matplotlib）
"""

import argparse
import csv
import glob
import math
import os
import statistics
import sys


def fnum(v):
    try:
        if v is None or v == "":
            return None
        return float(v)
    except (TypeError, ValueError):
        return None


def phase_rows(rows, phase):
    return [r for r in rows if r["status"].split("/")[-1] == phase]


def err_stats(rows):
    out = {}
    for axis in ("x", "y", "z"):
        vals = [fnum(r["err_" + axis]) for r in rows]
        vals = [v for v in vals if v is not None]
        if not vals:
            out[axis] = None
            continue
        mean = statistics.mean(vals)
        rms = math.sqrt(statistics.mean(v * v for v in vals))
        out[axis] = {
            "mean": mean,
            "rms": rms,
            "max": max(abs(v) for v in vals),
            "std": statistics.stdev(vals) if len(vals) > 1 else 0.0,
            "n": len(vals),
        }
    return out


def print_phase(title, rows):
    print("== %s  (n=%d) ==" % (title, len(rows)))
    s = err_stats(rows)
    if all(v is None for v in s.values()):
        print("  (无数据)")
        return s
    for axis, label in (("x", "X"), ("y", "Y"), ("z", "Z")):
        if s[axis]:
            print("  %s: mean=%+.3f cm  RMS=%.3f cm  max=%.3f cm  std=%.3f cm"
                  % (label, s[axis]["mean"] * 100, s[axis]["rms"] * 100,
                     s[axis]["max"] * 100, s[axis]["std"] * 100))
    return s


def print_events(rows):
    from collections import Counter
    c = Counter()
    for r in rows:
        ev = (r.get("events") or "").strip()
        if ev:
            for e in ev.split(" | "):
                c[e] += 1
    if c:
        print("== 安全/异常事件 ==")
        for msg, n in c.most_common(15):
            print("  %4d x %s" % (n, msg))


def print_extra(rows):
    vals = [fnum(r.get("ekf_err")) for r in rows]
    vals = [v for v in vals if v is not None]
    if vals:
        print("== EKF-mocap 误差 ==")
        print("  最后 %.3f m  最大 %.3f m  平均 %.3f m"
              % (vals[-1], max(vals), statistics.mean(vals)))
    from collections import Counter
    modes = Counter(r.get("extpose_mode") for r in rows if r.get("extpose_mode"))
    if modes:
        print("== 外部位姿 ==")
        print("  模式: %s" % dict(modes))
        sent = [int(r.get("extpose_sent")) for r in rows
                if str(r.get("extpose_sent", "")).isdigit()]
        errs = [int(r.get("extpose_errors")) for r in rows
                if str(r.get("extpose_errors", "")).isdigit()]
        if sent:
            print("  成功发送次数: %d (最后 %d)" % (sum(sent), sent[-1]))
        if errs:
            print("  失败次数: %d" % sum(errs))
    mpc_rows = [r for r in rows if (r.get("ctrl_mode") or "").startswith("mpc")]
    if mpc_rows:
        solve = [fnum(r.get("mpc_solve_ms")) for r in mpc_rows]
        solve = [v for v in solve if v is not None]
        parts = [r.get("mpc_backend", "") for r in mpc_rows
                 if r.get("mpc_backend")]
        print("== MPC ==")
        print("  控制周期: %d" % len(mpc_rows))
        if solve:
            print("  求解时间: mean=%.2fms max=%.2fms"
                  % (statistics.mean(solve), max(solve)))
        print("  后端: %s" % dict((p, parts.count(p)) for p in set(parts)))
        print("  求解失败: 最后 %s / 最大 %s"
              % (mpc_rows[-1].get("mpc_fails", "0"),
                 max(int(r.get("mpc_fails") or 0) for r in mpc_rows)))


def plot(rows, out_prefix):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("[plot] 未安装 matplotlib，跳过绘图 (pip3 install matplotlib)")
        return

    t = [fnum(r["t_s"]) for r in rows]
    px = [fnum(r["pos_x"]) for r in rows]
    py = [fnum(r["pos_y"]) for r in rows]
    pz = [fnum(r["pos_z"]) for r in rows]
    sx = [fnum(r["set_x"]) for r in rows]
    sy = [fnum(r["set_y"]) for r in rows]
    sz = [fnum(r["set_z"]) for r in rows]
    ex = [fnum(r["err_x"]) for r in rows]
    ey = [fnum(r["err_y"]) for r in rows]
    ez = [fnum(r["err_z"]) for r in rows]

    os.makedirs(os.path.dirname(out_prefix + "_trajectory.png"),
                exist_ok=True)

    fig1, ax1 = plt.subplots(figsize=(6, 5))
    ax1.plot(sx, sy, "r--", label="setpoint")
    ax1.plot(px, py, "b-", alpha=0.7, label="actual")
    ax1.set_xlabel("X (m)")
    ax1.set_ylabel("Y (m)")
    ax1.set_title("Trajectory")
    ax1.axis("equal")
    ax1.legend()
    fig1.tight_layout()
    fig1.savefig(out_prefix + "_trajectory.png", dpi=150)
    plt.close(fig1)

    fig2, ax2 = plt.subplots(figsize=(8, 4))
    ax2.plot(t, ex, label="err_x")
    ax2.plot(t, ey, label="err_y")
    ax2.plot(t, ez, label="err_z")
    ax2.set_xlabel("t (s)")
    ax2.set_ylabel("error (m)")
    ax2.set_title("Position error")
    ax2.legend()
    fig2.tight_layout()
    fig2.savefig(out_prefix + "_errors.png", dpi=150)
    plt.close(fig2)

    print("[plot] 已保存 %s_trajectory.png / _errors.png" % out_prefix)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?",
                    help="CSV 路径，缺省为 logs/ 下最新文件")
    args = ap.parse_args()

    path = args.csv
    if not path:
        cands = sorted(glob.glob("logs/*.csv"), key=os.path.getmtime)
        if not cands:
            print("logs/ 下没有 CSV，先跑一次 main.py")
            return 1
        path = cands[-1]
        print("[in] 使用最新日志: %s" % path)

    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print("空日志")
        return 1

    print("== 总览 ==")
    print("  时长 %.1fs, 行数 %d, 阶段: %s" % (
        (fnum(rows[-1]["t_s"]) or 0), len(rows),
        " -> ".join(dict.fromkeys(
            r["status"].split("/")[-1] for r in rows if r.get("status")))))

    stats = {}
    for phase in ("HOVER", "WAYPOINTS"):
        s = print_phase(phase, phase_rows(rows, phase))
        stats[phase] = s

    print_events(rows)
    print_extra(rows)
    prefix = os.path.splitext(path)[0]
    plot(rows, prefix)
    if stats["HOVER"] and all(stats["HOVER"][a] for a in "xyz"):
        print("\n[report] 报告可直接引用: 悬停 RMS_X=%.3fcm RMS_Y=%.3fcm RMS_Z=%.3fcm"
              % (stats["HOVER"]["x"]["rms"] * 100,
                 stats["HOVER"]["y"]["rms"] * 100,
                 stats["HOVER"]["z"]["rms"] * 100))
    return 0


if __name__ == "__main__":
    sys.exit(main())
