# -*- coding: utf-8 -*-
"""Check the host-side motion state estimator with simulated or live mocap.

Usage:
  python3 tools/check_estimator.py --sim --seconds 5
  python3 tools/check_estimator.py --config config.json --seconds 10
"""

import argparse
import json
import sys
import time

sys.path.insert(0, ".")
sys.path.insert(0, "..")

import nokov_client  # noqa: E402
import transform as tf  # noqa: E402
from state_estimator import MocapStateEstimator  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--seconds", type=float, default=5.0)
    ap.add_argument("--sim", action="store_true")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    source = nokov_client.make_source(cfg, sim=args.sim)
    source.connect()
    est_cfg = cfg.get("estimator", {})
    est = MocapStateEstimator(
        rate_hz=float(est_cfg.get("rate_hz", 50.0)),
        pos_std_m=float(est_cfg.get("pos_std_m", 0.01)),
        vel_std_mps=float(est_cfg.get("vel_std_mps", 0.05)),
        use_mocap_velocity=bool(est_cfg.get("use_mocap_velocity", True)),
    )
    if args.sim and hasattr(source, "set_target"):
        source.set_target(0.4, 0.2, 0.8)
    t0 = time.time()
    n = 0
    try:
        while time.time() - t0 < args.seconds:
            f = source.latest_frame()
            if f is None or not f.valid():
                time.sleep(0.002)
                continue
            pose = f.position_m()
            est.update(f, pose, f.yaw_deg)
            n += 1
    finally:
        source.disconnect()
    snap = est.snapshot()
    print("== estimator check ==")
    print("frames updated: %d" % n)
    print("ready         : %s" % snap["ready"])
    print("position      : (%.3f, %.3f, %.3f) m" % snap["pos"])
    print("velocity      : (%.3f, %.3f, %.3f) m/s" % snap["vel"])
    print("velocity src  : %s" % snap["vel_source"])
    print("rejected      : %d" % snap["rejected"])
    print("cov diag      : (%.6f, %.6f, %.6f, %.6f, %.6f, %.6f)"
          % snap["cov_diag"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
