"""Crazyflie 连接体检（不飞行）：扫描、参数、日志变量。

用法:  python3 tools/check_cf.py --uri radio://0/10/2M
"""

import argparse
import sys

sys.path.insert(0, ".")
sys.path.insert(0, "..")
import crazyflie_link  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uri", default="radio://0/91/2M/E7E7E7E791")
    args = ap.parse_args()

    if not crazyflie_link.HAS_CFLIB:
        print("未安装 cflib: pip3 install cflib")
        return 1

    import cflib.crtp
    cflib.crtp.init_drivers()
    print("---- 扫描到的接口 ----")
    for uri, name in cflib.crtp.scan_interfaces():
        print("  %-24s %s" % (uri, name))

    link = crazyflie_link.CrazyflieLink(args.uri)
    print("\n---- 连接 %s ----" % args.uri)
    if not link.connect(timeout=10.0):
        print("连接失败")
        return 1
    print("连接成功")

    cf = link.cf
    ptab = cf.param.toc.toc
    print("\n---- 参数总数: %d ----" % sum(len(v) for v in ptab.values()))

    checks = [
        ("stabilizer", "estimator"),
        ("locSrv", "extPosStdDev"),
        ("locSrv", "extQuatStdDev"),
        ("kalman", "resetEstimation"),
        ("kalman", "initialX"),
        ("kalman", "initialY"),
        ("kalman", "initialZ"),
        ("kalman", "initialYaw"),
        ("pm", "vbat"),
    ]
    print("---- 关键参数 ----")
    for g, n in checks:
        if g in ptab and n in ptab[g]:
            el = ptab[g][n]
            try:
                v = el.get_value()
            except Exception:
                v = "?"
            print("  %s.%s = %s" % (g, n, v))
        else:
            print("  %s.%s  (不存在)" % (g, n))

    print("---- 含关键字参数组 ----")
    for g in sorted(ptab):
        if any(k in g for k in ("kalman", "locSrv", "flightmode",
                                "stabilizer", "system", "commander")):
            names = ", ".join(sorted(ptab[g]))
            print("  [%s] %s" % (g, names))

    ltab = cf.log.toc.toc
    print("\n---- 日志变量(位置/姿态/电量) ----")
    for g in sorted(ltab):
        if g in ("kalman", "stateEstimate", "stabilizer", "pm"):
            names = ", ".join(sorted(ltab[g]))
            print("  [%s] %s" % (g, names))

    link.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

