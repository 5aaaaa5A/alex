# -*- coding: utf-8 -*-
"""Main entry."""

import argparse
import json
import math
import os
import sys
import threading
import time

import controller as ctrl_mod
import crazyflie_link
import nokov_client
import safety as safety_mod
import transform as tf
import waypoint_gen
from logger import FlightLogger
from state_estimator import MocapStateEstimator


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def wait_first_frame(source, timeout=10.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        f = source.latest_frame()
        if f is not None and f.valid():
            return f
        time.sleep(0.01)
    return None


class GatedLink:
    """Ground-mode safety gate."""

    def __init__(self, link, armed):
        self._link = link
        self.armed = armed
        self.skipped = 0

    def __getattr__(self, name):
        return getattr(self._link, name)

    def _skip(self, what):
        self.skipped += 1
        if self.skipped <= 5:
            print("[gated] no --flight, blocked: %s" % what)

    def send_position_setpoint(self, x, y, z, yaw_deg):
        if self.armed:
            self._link.send_position_setpoint(x, y, z, yaw_deg)
        else:
            self._skip("position setpoint")

    def send_velocity_world_setpoint(self, vx, vy, vz, yawrate):
        if self.armed:
            self._link.send_velocity_world_setpoint(vx, vy, vz, yawrate)
        else:
            self._skip("velocity setpoint")

    def send_attitude_setpoint(self, roll, pitch, yawrate, thrust):
        if self.armed:
            self._link.send_attitude_setpoint(roll, pitch, yawrate, thrust)
        else:
            self._skip("attitude setpoint")

    def send_extpose(self, x, y, z, quat):
        self._link.send_extpose(x, y, z, quat)

    def send_extpos(self, x, y, z):
        self._link.send_extpos(x, y, z)
        return True

    def send_stop(self):
        if self.armed:
            self._link.send_stop()
        else:
            self._skip("stop")


def keyboard_thread(ctrl):
    print("[kb] Space=land q=estop Ctrl+C=quit")
    while True:
        try:
            ch = input()
        except (EOFError, OSError):
            return
        s = ch.strip().lower()
        if s == "":
            ctrl.land_requested.set()
            print("[kb] land requested")
        elif s == "q":
            ctrl.estop_requested.set()
            print("[kb] estop requested")


def build_waypoints(cfg, args):
    mission_z = float(cfg.get("hover_z", cfg["takeoff_z"]))
    if args.rect:
        return waypoint_gen.rectangle(args.rect, mission_z, 0.0, 2.0)
    if args.circle:
        return waypoint_gen.circle(0.0, 0.0, args.circle,
                                   mission_z, n=args.circle_n)
    return cfg.get("waypoints", [])


def preflight_checks(link, safety, min_battery_v=3.8):
    state = link.get_state()
    pose = safety.get_pose()
    ex, ey, ez = state.get("x"), state.get("y"), state.get("z")
    err = None
    if None not in (ex, ey, ez):
        err = ((ex - pose[0]) ** 2 + (ey - pose[1]) ** 2
               + (ez - pose[2]) ** 2) ** 0.5
    stats = link.get_link_stats() if hasattr(link, "get_link_stats") else {}
    quality = stats.get("link_quality")
    battery = state.get("vbat")
    print("[check] EKF vs mocap error = %s m" %
          ("%.4f" % err if err is not None else "N/A"))
    print("[check] battery = %s V" %
          ("%.3f" % battery if battery is not None else "N/A"))
    print("[check] link quality = %s" %
          ("%.1f%%" % quality if quality is not None else "N/A"))
    print("[check] uplink RSSI = %s" %
          (stats.get("uplink_rssi", "N/A")))
    reasons = []
    if link.link_lost():
        reasons.append("radio link lost")
    if quality is not None and quality < 60.0:
        reasons.append("link quality %.0f%% < 60%%" % quality)
    if battery is None:
        reasons.append("battery not measured")
    elif battery < min_battery_v:
        reasons.append("battery %.3fV < %.2fV" % (battery, min_battery_v))
    if err is None:
        reasons.append("EKF position not measured")
    elif err > 0.05:
        reasons.append("EKF error %.3fm > 0.05m" % err)
    return len(reasons) == 0, reasons


def main():
    ap = argparse.ArgumentParser(description="Crazyflie + Nokov closed loop")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--dry-run", action="store_true",
                    help="do not connect Crazyflie")
    ap.add_argument("--flight", action="store_true",
                    help="allow real flight commands")
    ap.add_argument("--hover-only", action="store_true")
    ap.add_argument("--rect", type=float, default=0.0)
    ap.add_argument("--circle", type=float, default=0.0)
    ap.add_argument("--circle-n", type=int, default=24)
    ap.add_argument("--max-flight", type=float, default=90.0)
    ap.add_argument("--no-auto-origin", action="store_true")
    ap.add_argument("--log-dir", default=None)
    ap.add_argument("--tag", default="flight")
    ap.add_argument("--control-mode", choices=["official", "mpc"],
                    default=None, help="official firmware PID or host MPC")
    args = ap.parse_args()

    cfg = load_config(args.config)
    control_mode = args.control_mode or cfg.get("control", {}).get("mode", "official")
    if args.log_dir:
        cfg["log_dir"] = args.log_dir
    cfg["hover_only"] = args.hover_only

    logger = FlightLogger(cfg.get("log_dir", "logs"), tag=args.tag)
    print("[log] %s" % logger.path)
    print("[cf] build=v2 (extpose+ekf reset+takeoff ramp+preflight)")

    link = None
    if args.dry_run:
        link = crazyflie_link.FakeLink(verbose=True)
        print("[cf] dry-run: no Crazyflie connection")
    else:
        link = crazyflie_link.CrazyflieLink(cfg["radio_uri"])
        print("[cf] connecting %s ..." % cfg["radio_uri"])
        if not link.connect(timeout=10.0):
            print("[cf] connect failed")
            logger.close()
            return 1
        print("[cf] link_build=%s" % getattr(link, "link_build", "?"))
        for a in link.setup_for_external_position(
                cfg.get("ext_pos_stddev", 0.01),
                cfg.get("ext_quat_stddev", 0.05)):
            print("[cf] %s" % a)

    gated = GatedLink(link, armed=(args.flight or args.dry_run))

    source = nokov_client.make_source(cfg, sim=args.sim)
    print("[mocap] connecting %s ..." %
          ("sim" if args.sim else cfg.get("nokov_server_ip")))
    try:
        source.connect()
    except Exception as exc:
        print("[mocap] connect failed: %s" % exc)
        link.close()
        logger.close()
        return 1

    if args.dry_run and hasattr(link, "_target_sink"):
        link._target_sink = source.set_target

    frame0 = wait_first_frame(source, timeout=10.0)
    if frame0 is None:
        print("[mocap] no valid frame in 10s")
        source.disconnect()
        link.close()
        logger.close()
        return 1
    if args.no_auto_origin:
        origin = tuple(cfg["origin"])
        yaw_off = cfg["yaw_offset_deg"]
        print("[tf] config origin=%s yaw_offset=%.2f" % (origin, yaw_off))
    else:
        origin = (frame0.x_mm, frame0.y_mm, frame0.z_mm)
        yaw_off = frame0.yaw_deg
        print("[tf] auto origin=(%.2f,%.2f,%.2f)mm yaw_offset=%.2fdeg"
              % (origin + (yaw_off,)))
        print("[tf] nose direction will be CF world +X (yaw=0)")
    transform = tf.MocapToCF(origin, yaw_off)

    safety = safety_mod.SafetyMonitor(cfg.get("safety", {}))
    est_cfg = cfg.get("estimator", {})
    estimator = MocapStateEstimator(
        rate_hz=float(est_cfg.get("rate_hz", 50.0)),
        pos_std_m=float(est_cfg.get("pos_std_m", cfg.get("ext_pos_stddev", 0.01))),
        vel_std_mps=float(est_cfg.get("vel_std_mps", 0.05)),
        use_mocap_velocity=bool(est_cfg.get("use_mocap_velocity", True)),
    )
    feeder = crazyflie_link.ExtposFeeder(
        source, transform, safety,
        link=None if args.dry_run else gated,
        rate_hz=cfg["extpos_rate_hz"],
        use_extpose=cfg.get("use_extpose", True),
        state_estimator=estimator)
    feeder.start()
    time.sleep(0.5)

    if not args.dry_run:
        p = transform.apply(frame0)
        link.reset_ekf(p["x"], p["y"], p["z"], math.radians(p["yaw_deg"]))
        print("[cf] EKF initial=(%.3f, %.3f, %.3f) yaw=%.1fdeg"
              % (p["x"], p["y"], p["z"], p["yaw_deg"]))
        try:
            ok = link.wait_ekf_convergence(timeout_s=20.0)
        except Exception as exc:
            print("[cf] EKF convergence check failed: %s" % exc)
            ok = False
        if not ok:
            print("[cf] covariance did not converge; keep waiting 3s")
        time.sleep(1.0)
        try:
            link.start_state_log(period_ms=cfg.get("state_log_period_ms", 100))
        except Exception as exc:
            print("[cf] state log start failed: %s" % exc)
        time.sleep(1.0)
        fly_ok, reasons = preflight_checks(
            link, safety,
            min_battery_v=float(
                cfg.get("safety", {}).get("preflight_min_battery_v", 3.5)))
        ep = feeder.snapshot()
        print("[check] extpose mode=%s sent=%d errors=%d last_age=%s%s"
              % (ep.get("last_send_mode", "?"), ep.get("send_success", 0),
                 ep.get("send_errors", 0), ep.get("last_send_age_s", "?"),
                 (" err=%s" % ep.get("last_send_error"))
                 if ep.get("last_send_error") else ""))
        if ep.get("last_send_error"):
            print("[check] extpose error detail: %s" % ep["last_send_error"])
        if ep.get("send_errors", 0) > 0 or ep.get("last_send_mode") == "error":
            fly_ok = False
            reasons.append("extpose send failed")
        print("[check] ready=%s reasons=%s" % (fly_ok, reasons))
        if args.flight and not fly_ok:
            print("[main] flight blocked by preflight checks")
            feeder.stop()
            source.disconnect()
            link.close()
            logger.close()
            return 2
    else:
        fly_ok, reasons = False, []

    ctrl = ctrl_mod.FlightController(
        gated, safety, feeder, cfg, logger=logger,
        waypoints=build_waypoints(cfg, args),
        battery_provider=(link.get_state if not args.dry_run else None),
        flight_enabled=bool(args.flight or args.dry_run),
        state_estimator=estimator,
        control_mode=control_mode)
    print("[ctrl] mode=%s (mpc=%s)" % (control_mode, control_mode == "mpc"))
    kb = threading.Thread(target=keyboard_thread, args=(ctrl,), daemon=True)
    kb.start()

    if args.flight and not args.dry_run:
        ok = link.arm()
        print("[cf] arming request %s" % ("sent" if ok else "unavailable"))

    if args.flight:
        print("\n!!! REAL FLIGHT starting in 5s, Ctrl+C to abort !!!")
        for i in range(5, 0, -1):
            print("  %d..." % i)
            time.sleep(1.0)

    print("[go] controller started (max %.0fs)" % args.max_flight)
    try:
        ctrl.run(max_flight_s=args.max_flight)
    except KeyboardInterrupt:
        print("\n[main] Ctrl+C -> estop")
        ctrl.estop_requested.set()
        if not args.dry_run:
            gated.send_stop()
    finally:
        print("[main] stopping... reason=%s state=%s"
              % (ctrl.stop_reason, ctrl.state))
        feeder.stop()
        source.disconnect()
        if not args.dry_run:
            link.close()
        logger.close()

    print("[main] log: %s" % logger.path)
    evs = list(safety.events)
    if evs:
        print("[main] safety events:")
        for t, m in evs[-10:]:
            print("   %s" % m)
    return 0


if __name__ == "__main__":
    rc = main()
    sys.stdout.flush()
    os._exit(rc)
