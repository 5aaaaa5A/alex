# Crazyflie 动捕闭环：MPC 与姿态/传感器校准实施方案

## 0. 结论

推荐按下面三层实现：

| 层级 | 内容 | 难度 | 建议 |
|---|---|---|---|
| **Tier 1（核心）** | 上位机“平移 MPC + 固件速度/姿态内环” | 中 | 优先完成，作为正式方案 |
| **Tier 2（比较）** | MPC 输出直接改为姿态/推力指令 | 高 | 在 Tier 1 飞稳后，作为加分拓展 |
| **Tier 3（选做）** | 动捕辅助的姿态/IMU 偏差估计与自动调平 | 中高 | 先做离线标定，再做在线估计 |

Tier 1 虽然 MPC 只负责平移动力学，但仍属于完整的状态反馈控制：上位机用 Nokov 位置/速度估计状态，通过 QP 求约束最优控制量，再把控制量交给 Crazyflie 固件的速度/姿态内环执行。这样可以避开“直接姿态 MPC”需要的质量、推力系数、惯性参数和姿态指令带宽等大量标定工作，同时保留现有安全层。

Tier 2 才真正绕过固件位置控制，把 MPC 输出的期望加速度转换为 roll/pitch/thrust，直接发送给固件姿态环。该项风险高、实验周期长，建议仅在 Tier 1 完成且时间充裕时选择实现。

## 1. 现有项目框架理解

### 1.1 数据链路

```text
Nokov 相机
  -> nokov_bridge.cpp（SDK 回调，约 50-100 Hz）
  -> nokov_reader.py（ctypes，RigidBody/ExtendData）
  -> nokov_client.RealNokov.latest_frame()
  -> MocapFrame
  -> ExtposFeeder._run()（约 20 Hz）
  -> CrazyflieLink.send_extpos() / send_extpose()
  -> Crazyflie 固件 EKF（stabilizer.estimator=2）
  -> kalman.stateX/Y/Z
  -> FlightLogger / SafetyMonitor
```

### 1.2 控制链路

当前 `FlightController` 只做任务状态机和参考点生成：

```text
IDLE -> UNLOCK -> TAKEOFF -> CLIMB -> HOVER -> WAYPOINTS -> LAND -> STOP
```

在 `HOVER/WAYPOINTS` 中，代码调用：

```python
link.send_position_setpoint(x, y, z, yaw_deg)
```

真正的位置控制、速度控制、姿态控制和电机分配都在 Crazyflie 固件中完成。当前代码本质是 **官方 SDK + 固件 PID**，上位机没有闭环控制，只把动捕坐标和任务参考点送给固件。

### 1.3 关键接口

`crazyflie_link.py` 已经提供：

- `send_position_setpoint(x, y, z, yaw_deg)`：固件位置控制器。
- `send_velocity_world_setpoint(vx, vy, vz, yawrate)`：固件速度控制器。
- `send_attitude_setpoint(roll, pitch, yawrate, thrust)`：固件姿态角控制器。
- `send_extpos()`：只发送位置。
- `send_extpose()`：同时发送位置和四元数。
- `reset_ekf()`、`wait_ekf_convergence()`、`get_state()`：初始化与 EKF 状态读取。

当前 `config.json` 中 `use_extpose=false`，即实际发送的是 **extpos** 而不是 extpose。位置外源可用，但姿态主要由 Crazyflie 内部 IMU/EKF 估计。这个细节对“姿态校准”选做项很重要。

### 1.4 当前项目需要补齐的部分

1. `MocapFrame` 没有保存 Nokov `ExtendData` 中的速度、加速度、角速度和角加速度；这些数据桥已经提供，但目前被丢弃。
2. 没有上位机状态估计器；`SafetyMonitor` 只维护位置，不维护速度。
3. 没有参考轨迹的期望速度/加速度；`waypoint_gen.py` 只生成位置点。
4. 没有 MPC 求解器、命令限幅、命令平滑和求解失败保护。
5. 日志没有记录速度、MPC 控制量和模式；`analyze_log.py` 因此只能比较位置误差。
6. `FakeLink/SimMocap` 只是一阶位置跟随，无法验证 MPC 和状态估计。
7. 坐标变换只标定 origin 和 yaw，没有完整姿态装配误差 `R_cal`。

## 2. Tier 1 核心设计
### 2.1 设计思想

把状态分为两层：

- **MPC 外环**：负责世界坐标系下的平移跟踪，考虑位置、速度、加速度、边界约束。
- **固件内环**：负责把 MPC 给出的世界速度指令稳定执行。

MPC 每一拍输出期望加速度 `a_des`，再用一阶预测得到期望速度：

```text
v_des = v_hat + a_des * dt_control
```

最后调用：

```python
link.send_velocity_world_setpoint(vx, vy, vz, yawrate)
```

这样 MPC 是真正参与闭环的，不是只发位置点。

### 2.2 状态模型

取状态：

```text
x = [px, py, pz, vx, vy, vz]^T
u = [ax, ay, az]^T
```

离散化后的双积分模型：

```text
p_{k+1} = p_k + v_k * Ts + 0.5 * a_k * Ts^2
v_{k+1} = v_k + a_k * Ts
```

矩阵形式：

```text
A = [[I, Ts*I],
     [0, I]]

B = [[0.5*Ts^2*I],
     [Ts*I]]
```

若状态估计器包含加速度偏置 `b_a`，可扩展为：

```text
x = [p, v, b_a]
```

并使用：

```text
p_{k+1} = p_k + v_k * Ts + 0.5*(a_k + b_a_k) * Ts^2
v_{k+1} = v_k + (a_k + b_a_k) * Ts
b_{k+1} = b_a_k
```

### 2.3 目标函数

```text
J = sum_{k=0}^{N-1} [ (x_k - r_k)^T Q (x_k - r_k)
                      + u_k^T R u_k
                      + Δu_k^T S Δu_k ]
    + (x_N - r_N)^T Qf (x_N - r_N)
```

其中：

- `r_k` 是参考轨迹在预测时刻的位置、速度。
- `Q` 惩罚位置和速度跟踪误差。
- `R` 惩罚加速度幅值。
- `S` 惩罚相邻控制量变化，防止抖振。
- `Qf` 是终端代价，用于保证末端收敛。

建议初始参数：

```text
Q_p = diag(8, 8, 12)
Q_v = diag(1.2, 1.2, 1.5)
R   = diag(0.12, 0.12, 0.18)
S   = diag(0.35, 0.35, 0.45)
```

具体权重需要通过仿真再调，不能直接搬到实机。

### 2.4 约束

```text
|vx| <= vmax_xy
|vy| <= vmax_xy
|vz| <= vmax_z

|ax| <= amax_xy
|ay| <= amax_xy
|az| <= amax_z

|a_t - a_{t-1}| <= jerk_max * Ts

x_min <= x <= x_max
y_min <= y <= y_max
z_min <= z <= z_max
```

建议初始值：

```text
vmax_xy = 0.8 m/s
vmax_z  = 0.4 m/s
amax_xy = 1.2 m/s^2
amax_z  = 0.8 m/s^2
jerk_max = 1.2 m/s^3
```

电子围栏约束建议取绝对安全围栏的 `80%-90%`，给 MPC 预测误差留余量。

### 2.5 求解器

优先使用：

```bash
pip3 install osqp numpy
```

OSQP 适合这种凸 QP，支持 warm-start，在树莓派 4 上一般可以在几毫秒内完成。

默认参数：

```text
MPC rate = 20 Hz
Ts       = 0.05 s
N        = 12 ~ 20
eps_abs  = 1e-4
eps_rel  = 1e-4
warm_start = True
```

如果树莓派实测单次求解超过 `8-10 ms`，优先降低 `N` 或降到 `10 Hz`，不要为了性能牺牲安全。

若现场不能安装 OSQP，作为最小可行替代：

- 先实现“约束 LQR/有限时域解析预测”，在无约束情况下以 LQR 输出为基准。
- 再用简单的饱和限幅保证安全。
- 但这样不能严格称为 MPC，报告里必须说明。

### 2.6 参考轨迹生成

不能只给 MPC 一个位置点，否则 `r_k` 中速度恒为零，MPC 会表现出类似 PD 的行为。应在轨迹生成时同步输出位置、速度、加速度。

`waypoint_gen.py` 增加：

```python
class TrajectoryGenerator:
    def __init__(self, waypoints, vmax, amax, jerk_max): ...

    def sample(self, t):
        """返回 (position, velocity, acceleration)。"""
```

建议先实现三类：

1. **悬停**：目标位置固定，`p_ref = const`，`v_ref = 0`，`a_ref = 0`。
2. **圆轨迹**：使用解析导数：
   ```text
   x = cx + r*cos(ωt)
   y = cy + r*sin(ωt)
   vx = -r*ω*sin(ωt)
   vy =  r*ω*cos(ωt)
   ```
3. **航点直线/最小加加速度轨迹**：在两点之间生成满足位置、速度、加速度约束的 `Trapezoidal` 或 `Minimum Jerk` 轨迹。

### 2.7 状态估计器

新增 `state_estimator.py`，提供：

```python
class MotionStateEstimator:
    def update(self, frame, command, timestamp): ...
    def snapshot(self): ...
```

优先使用 Nokov `ExtendData` 自带的速度：

```text
v_mps = (vx_mm_s, vy_mm_s, vz_mm_s) / 1000
```

原因是动捕速度是真实测量，比位置差分噪声小，而且可以避免差分放大高频噪声。

当 `has_extend=False` 或 `mean_error` 超过阈值时，退化为 6 状态 / 9 状态卡尔曼滤波：

```text
量测：z = [px, py, pz]
过程噪声：Q_kf
量测噪声：R_kf ≈ locSrv.extPosStdDev^2
```

若 Nokov 延迟明显，再加入延迟补偿：

```text
t_measure = frame.recv_ts - frame.latency
t_now     = time.time()
x_hat(t_now) = x_pred(t_measure + t_now - t_measure)
```

上位机状态估计频率建议：

```text
Nokov 原始帧：50-100 Hz
状态估计器： 50 Hz
MPC 控制：   20 Hz
命令发送：   20 Hz
## 3. Tier 1 代码改造

### 3.1 新增文件

```text
state_estimator.py        # 动捕状态估计器
trajectory_gen.py         # 生成位置/速度/加速度参考轨迹
mpc_controller.py         # OSQP 形式的平移 MPC
command_limiter.py        # 速度/加速度/ jerk 限幅与饱和统计
```

### 3.2 修改文件

`nokov_client.py`：

- `MocapFrame` 增加 `has_extend`、`vx_mps`、`vy_mps`、`vz_mps`、`roll_vel_dps`、`pitch_vel_dps`、`yaw_vel_dps`、`ax_mps2`、`ay_mps2`、`az_mps2`。
- `RealNokov.latest_frame()` 从 `body` 读取扩展数据。

`config.json`：

```json
{
  "control": {
    "mode": "mpc_velocity",
    "rate_hz": 20,
    "horizon": 15,
    "dt": 0.05,
    "output": "velocity",
    "fallback_mode": "official"
  },
  "mpc": {
    "vmax_xy": 0.8,
    "vmax_z": 0.4,
    "amax_xy": 1.2,
    "amax_z": 0.8,
    "jerk_max": 1.2
  },
  "estimator": {
    "rate_hz": 50,
    "enable_bias": true,
    "use_mocap_velocity": true,
    "pos_std_m": 0.01
  }
}
```

`main.py`：

- 增加 `--control-mode official|mpc|attitude-mpc`。
- 增加 `--tag mpc`、`--tag official` 用于区分实验。
- 把 `mode` 传入 `FlightController`。
- 预检中检查 OSQP 是否能导入、是否能在 `N` 步内求解。

`controller.py`：

- `FlightController` 增加 `control_mode`、`mpc`、`state_estimator`、`command_limiter`。
- 只允许 `HOVER/WAYPOINTS` 状态启用 MPC。
- `TAKEOFF/CLIMB/LAND/STOP` 继续使用现有逻辑。
- `status != OK` 时立即回退官方位置模式，不继续调用 MPC。
- 增加“MPC 求解失败统计”，连续失败超过阈值则触发 `LAND` 或 `STOP`。

`crazyflie_link.py`：

- 增加 `send_mpc_velocity()` 或保持 `send_velocity_world_setpoint()`。
- 每次发送前记录 `last_mpc_cmd`，供日志和 fallback 使用。
- 如果 `send_velocity_world_setpoint` 内部抛错，设置 `last_setpoint_error`，控制器据此切换回 `official`。

`logger.py`：

增加字段：

```text
ctrl_mode
state_vx, state_vy, state_vz
ref_x, ref_y, ref_z
ref_vx, ref_vy, ref_vz
mpc_ax, mpc_ay, mpc_az
cmd_vx, cmd_vy, cmd_vz
mpc_solve_ms
mpc_fails
cmd_saturated
```

`tools/analyze_log.py`：

增加：

- 按 `ctrl_mode` 分组统计。
- 计算位置 RMS、速度 RMS、控制量 RMS、求解耗时。
- 绘制 `state_v` 与 `ref_v`、`mpc_a`、`cmd_v` 曲线。

## 4. Tier 2：直接姿态/推力 MPC
### 4.1 动机

如果只发送速度指令，固件的速度控制器仍然是一个 PID。为了真正比较“官方 SDK PID 控制”与“MPC 状态反馈控制”，可以进一步让 MPC 直接输出姿态角与推力，绕过固件位置/速度控制器。

这也是与图片中“控制算法拓展”最接近的完整实现。

### 4.2 控制映射

MPC 输出世界系期望加速度：

```text
a_world = [ax, ay, az]
```

先转到机体系：

```text
a_body = R_yaw^T * a_world
```

在小角度假设下：

```text
pitch_ref ≈ atan2(a_body_x, g)
roll_ref  ≈ -atan2(a_body_y, g)
thrust_ref / thrust_hover ≈ (g + a_body_z) / g
```

`thrust_hover` 需要标定。可以先在地面读取悬停时固件输出的 `stabilizer.thrust`，或通过试飞到稳定悬停后反推。

然后调用：

```python
link.send_attitude_setpoint(roll_deg, pitch_deg, yawrate, thrust)
```

注意：**上面的 roll/pitch 符号只是初始公式**。Crazyflie 固件对 roll/pitch 的正方向在不同版本/坐标系下可能不同，必须在实机上做单轴阶跃标定：

1. 只给 `pitch=+3°`，观察无人机是否向世界坐标系 `+X` 倾斜；如果不是，修改符号。
2. 只给 `roll=+3°`，观察是否向 `+Y` 倾斜；如果不是，修改符号。
3. 记录 `roll/pitch -> 加速度` 的线性斜率，用于修正比例。

### 4.3 带宽与执行线程

直接姿态指令不能继续用 10 Hz 的控制器频率，姿态环需要更高带宽，建议：

```text
MPC rate = 50 Hz（推荐）
命令发送 = 50 Hz
状态估计 = 50-100 Hz
```

但 50 Hz 的姿态指令 + 20 Hz extpose + 日志可能对 Crazyradio 带宽造成压力。实际方案：

- 先用 20 Hz 验证没有明显抖振。
- 再逐步升到 30/50 Hz。
- 飞行中关闭或降低日志频率。
- 检查 `link_quality`、`uplink_congestion`、`downlink_congestion`。

## 5. Tier 3：动捕辅助姿态校准 / IMU 偏差估计 / 自动调平
### 5.1 问题来源

图片中的选做项针对三类问题：

- 无人机标记点/刚体装配误差。
- IMU 零偏。
- 起飞时无人机初始姿态不水平。

当前 `transform.py` 只处理 `origin` 和 `yaw_offset`，没有处理 roll/pitch 的装配误差；`use_extpose=false` 时 CF EKF 也不会直接接收动捕姿态，因此内部姿态估计可能引入偏差。

### 5.2 推荐实现顺序

#### 第一步：完整刚体标定 `R_cal`

把 Nokov 刚体坐标系和 Crazyflie 机体坐标系的常数旋转误差异常标定出来。

```text
q_cf = q_cal ⊗ q_nokov
```

标定方法：

1. 分别在 4-8 个已知姿态（如平放、左右倾 10°、前后倾 10°、转 90°）下静止 5-10 秒。
2. 同时记录 Nokov 四元数和 CF 内部姿态 `stateEstimate.roll/pitch/yaw`。
3. 用 Wahba 问题 / 四元数最小二乘估计 `R_cal`。
4. 把 `R_cal` 保存到 `config.json`。

`MocapToCF` 从只支持 yaw 扩展为：

```python
transform = MocapToCF(
    origin_mm=(...),
    yaw_offset_deg=(...),
    orientation_calibration=q_cal,
)
```

#### 第二步：IMU 零偏离线估计

分别在静止和缓慢转动时采集：

```text
imu.acc.x/y/z
imu.gyro.x/y/z
stabilizer.roll/pitch/yaw
stateEstimate.x/y/z
```

静止数据估计：

```text
gyro_bias = median(gyro_static)
acc_static = mean(acc_static)
```

旋转数据估计：

```text
omega_gyro ≈ G * omega_nokov + b_g
```

用最小二乘估计：

- 陀螺仪零偏 `b_g`。
- 加速度计零偏 `b_a`。
- 陀螺仪尺度/轴间耦合矩阵 `G`。
- 刚体到机体的旋转 `R_cal`。

如果固件或 cflib 支持 `imu.accOffset*`、`imu.gyroOffset*` 等参数，可把估计结果写入固件；否则在上位机状态估计器中补偿。

#### 第三步：起飞初始姿态校准 / 自动调平

起飞前保持静止 3-5 秒，记录 Nokov 实测初始姿态：

```text
roll0, pitch0, yaw0
```

两种处理方式：

1. **使用 extpose（推荐作为验证）**
   ```json
   "use_extpose": true
   ```
   Nokov 姿态直接进入 CF EKF，起飞前调平问题基本被外源解决。

2. **仅用 extpos，上位机补偿**
   将初始姿态偏差作为常数偏移保存：
   ```text
   roll_cmd = roll_mpc - roll0
   pitch_cmd = pitch_mpc - pitch0
   ```
   该公式的符号需要通过一次地面/小高度悬浮实验确认，避免把偏差方向弄反。

#### 第四步（可选）：在线偏差估计

如果时间充足，可在状态估计器中加入：

```text
x = [p, v, b_a, roll, pitch, yaw, b_g]
```

使用误差状态卡尔曼滤波（ESKF）：

- 量测：Nokov 位置、Nokov 速度、Nokov 四元数。
- 预测：IMU 加速度、角速度。
- 输出：速度、姿态、加速度偏置、陀螺仪偏置。

该选做项会显著增加代码量和标定工作量，建议先完成离线批处理，再用 ESKF 作为最后加分项。

## 6. 官方 SDK 与 MPC 对比实验设计
### 6.1 实验变量

固定条件：

- 同一台 Crazyflie。
- 同一条随机航点 / 圆轨迹 / 矩形轨迹。
- 同一动捕刚体与坐标标定。
- 新电池或相同电压区间。
- 同一飞行高度、同一起飞点、同一初始姿态。
- 同一实验人员与 TA 在场。

独立变量：

```text
official  = CF 官方位置设定点模式
mpc       = Tier 1 平移 MPC 速度指令模式
mpc_att   = Tier 2 姿态/推力 MPC 模式（可选）
```

每个模式至少采集 3 次有效数据，交替顺序进行，减少电池和场地状态偏差。

### 6.2 评价指标

```text
位置误差：
  RMS_x, RMS_y, RMS_z
  mean_x, mean_y, mean_z
  max_x, max_y, max_z

速度误差：
  RMS_vx, RMS_vy, RMS_vz

响应指标：
  5% 到 95% 到达时间
  超调量
  稳定时间（误差连续低于阈值）

控制质量：
  加速度 RMS
  jerk RMS
  姿态角 RMS（若已记录）
  推力 RMS（若已记录）

鲁棒性：
  注入 100-200 ms 动捕丢帧时的最大误差
  注入 0.1-0.3 m 位置跳变时的最大误差
  求解失败次数统计
```

### 6.3 输出

新增 `tools/compare_logs.py`：

```text
usage: python3 tools/compare_logs.py --official logs/xxx_official.csv --mpc logs/xxx_mpc.csv
```

输出：

- 控制台指标表。
- 轨迹对比图。
- 误差时间曲线。
- 速度/控制量时间曲线。
- 汇总 CSV：`logs/control_compare_summary.csv`。

## 7. 实施步骤
| 阶段 | 内容 | 验证方法 |
|---|---|---|
| P0 | 核对 `cflib` 版本、Commander API、固件参数 TOC | `tools/check_cf.py` 扩展输出 |
| P1 | 扩充 `MocapFrame`，保存速度/角速度/加速度 | `tools/check_nokov.py` 显示速度 |
| P2 | 上位机状态估计器 | `tools/check_estimator.py` |
| P3 | 参考轨迹生成器 | 离线绘制位置/速度/加速度 |
| P4 | OSQP 平移 MPC | 离线单点、圆轨迹仿真 |
| P5 | 接入 `FlightController`，日志与限幅 | `python main.py --sim --dry-run` |
| P6 | 实验室地面模式 / 小高度悬停 | A/B 悬停日志 |
| P7 | 航点、圆轨迹对比 | `tools/compare_logs.py` |
| P8 | 离线姿态/IMU 校准 | `tools/calibrate_imu.py` |
| P9 | 自动调平验证 | 非水平起飞对比 |
| P10 | 可选 ESKF / 直接姿态 MPC | 小高度单轴阶跃 |

## 8. 风险与缓解

| 风险 | 缓解 |
|---|---|
| MPC 求解超时 | warm-start、降 N、降频率、失败时回退官方模式 |
| 无线电带宽不足 | 20 Hz 控制、降低日志频率、必要时使用 1M/2M 链路 |
| Nokov 速度噪声大 | 用 `mean_error` 门控、低通滤波、状态估计器融合 |
| 模型不准确 | 先做单轴阶跃辨识；限制加速度和 jerk |
| 坐标系/符号错误 | `check_transform.py` 单轴标定；实机小角度验证 |
| 固件 API 差异 | 以 `check_cf.py` 和 TOC 为准，不硬编码参数 |
| 直接姿态 MPC 失稳 | 只在 20-30° 内、低高度、TA 在场、先小推力阶跃 |
| 与官方模式切换产生跳变 | 切换前保持速度连续，增加 0.2-0.5 s 过渡 |
| 电池影响对比公平性 | 每次实验记录电池电压，尽量同区间比较 |

## 9. 可交付物

- `state_estimator.py`
- `trajectory_gen.py`
- `mpc_controller.py`
- `command_limiter.py`
- `tools/check_estimator.py`
- `tools/compare_logs.py`
- `tools/calibrate_imu.py`
- 扩展后的 `analyze_log.py`
- `config.json` 中的 `control/mpc/estimator` 配置
- 官方与 MPC 各 3 次实验 CSV
- 对比图与汇总表
- 课程报告所需数据：RMS、超调、稳定时间、求解时间、控制量、安全事件

## 10. 最终推荐路线

1. 先完成 Tier 1，即“**上位机平移 MPC + 固件速度内环**”。它可控、可测、可安全回退，并且已经能区别于官方 SDK 的位置模式。
2. 若时间允许，再实现 Tier 2“**直接姿态/推力 MPC**”，这才是最完整的“MPC 替代官方 PID”的形态。
3. 选做项先做“**离线刚体姿态标定 + IMU 零偏估计 + 起飞自动调平**”；在线 ESKF 只作为最后冲刺任务。
## 11. Tier 1 已实现代码

### 新增文件

- `state_estimator.py`：Nokov 位置/速度融合的 6 状态卡尔曼估计器。
- `trajectory_gen.py`：航点梯形速度参考轨迹，输出位置/速度/加速度；按 X/Y/Z 独立速度、加速度上限规划。
- `mpc_controller.py`：平移 MPC；树莓派装有 `osqp` 时自动走 OSQP，否则走内置投影梯度 QP。
- `command_limiter.py`：加速、速度、jerk 与电子围栏安全限幅。
- `tools/check_estimator.py`：状态估计器检查。
- `tools/compare_logs.py`：官方与 MPC 日志同阶段对比，输出轨迹、误差、速度、RMS、MPC 指标图和汇总 CSV。

### 修改文件

- `nokov_client.py`：保存 Nokov 速度、角速度、加速度和 `has_extend`。
- `crazyflie_link.py`：`ExtposFeeder` 接入状态估计器。
- `controller.py`：新增 `--control-mode mpc` 的 HOVER/WAYPOINTS 执行路径；MPC 航点按参考轨迹段完成时刻推进。
- `main.py`：参数解析、默认控制模式、状态估计器和 MPC 接线。
- `config.json`：新增 `control`、`mpc`、`estimator` 配置。
- `logger.py`：记录状态、参考、MPC 控制量、求解时间和饱和次数。
- `tools/analyze_log.py`、`tools/check_nokov.py`、`README.md`、`pi_setup.sh`：同步更新。

### 已通过验证

- 全部 Python 文件 `compileall` 通过。
- `python main.py --sim --dry-run --control-mode official` 通过。
- `python main.py --sim --dry-run --control-mode mpc --max-flight 60` 通过，完整走完 15 个随机航点并自动降落。
- `python main.py --sim --dry-run --control-mode mpc --max-flight 16` 通过，自动完成 `UNLOCK -> TAKEOFF -> CLIMB -> HOVER -> WAYPOINTS -> LAND -> STOP`。
- MPC dry-run：100 个 HOVER 控制周期，`mpc_fails=0`；求解时间 mean 约 1.7 ms、max 约 3 ms；仿真 X/Y RMS 约 0.14-0.17 cm。Z 轴包含从 0.9 m 到 1.0 m 的收敛过程，RMS 约 3.2 cm。
- 统一平滑参考下，WAYPOINTS 阶段官方 3D RMS 约 48.8 cm，MPC 约 31.9 cm；MPC 求解失败 0 次。详细结果见 `outputs/MPC官方SDK对比结果.md` 与 `outputs/compare/`。
- 以上结果来自简化仿真，实机需要先做一次短悬停，再按 `control/mpc` 权重和限幅微调。

### 使用方式

```bash
# 官方固件 PID
python3 main.py --config config.json --sim --dry-run --control-mode official

# 上位机 MPC
python3 main.py --config config.json --sim --dry-run --control-mode mpc

# 实机（先 TA 在场，首次请先 hover-only）
python3 main.py --config config.json --flight --hover-only --control-mode mpc --tag mpc_hover

# 对比
python3 tools/compare_logs.py --official logs/xxx_official.csv \
  --mpc logs/xxx_mpc.csv --phase HOVER,WAYPOINTS --config config.json \
  --plot-dir outputs/compare --out outputs/compare/official_vs_mpc_summary.csv
```

改动后的完整代码位于 `outputs/91random-mpc.zip`。
