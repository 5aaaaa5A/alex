# MPC 与官方 SDK 对比结果

## 1. 说明

本文档比较两条等价飞行策略：

- **official**：Crazyflie 官方 `cflib` + 固件位置 setpoint 模式，上位机只发送目标点。
- **mpc**：实施方案中的 Tier 1 上位机平移 MPC，输出速度指令，固件执行速度内环。

比较依据为同一条随机航点任务，使用同一组 `config.json` 航点、同样的起飞点和动捕仿真噪声。用户已确认不使用云端 origin，因此本次数据处理完全基于本地 CSV 日志与统一参考轨迹，不做坐标原点差异比较。

本次数据为 `--sim --dry-run` 仿真日志，不是实机飞行。结果可用于验证算法链路、对比相对趋势和识别调参方向；最终实验结论需要以实验室同电池、同航点的实机 3 次重复测试为准。

## 2. 本次比较数据

| 项目 | 官方日志 | MPC 日志 |
|---|---|---|
| 任务 | 15 个随机航点 | 15 个随机航点 |
| 模式 | `--control-mode official` | `--control-mode mpc` |
| 总时长 | 53.5 s | 61.3 s |
| 航点阶段时长 | 38.7 s | 46.9 s |
| 完整状态序列 | 完成到 LAND/STOP | 完成到 LAND/STOP |

## 3. 统一参考轨迹误差（建议采用的公平指标）

由于官方模式发送的是阶跃式位置 setpoint，MPC 发送的是平滑参考轨迹，直接用两者日志中的 `err_x/y/z` 比较会高估 MPC 误差。因此工具先按同一组航点和同一组 X/Y/Z 速度、加速度约束重建“统一平滑参考轨迹”，再计算双方相对这条参考的跟踪误差。

| 阶段 | 指标 | 官方 | MPC | 改善 |
|---|---|---|---:|---:|
| HOVER | X RMS | 0.143 cm | 0.154 cm | -7.7% |
| HOVER | Y RMS | 0.147 cm | 0.156 cm | -6.1% |
| HOVER | Z RMS（含爬升入稳段） | 1.890 cm | 3.163 cm | -67.4% |
| HOVER 后 1 s 稳态 | Z RMS | 0.191 cm | 1.203 cm | -530% |
| WAYPOINTS | X RMS | 29.86 cm | 25.25 cm | +15.4% |
| WAYPOINTS | Y RMS | 37.10 cm | 18.19 cm | +51.0% |
| WAYPOINTS | Z RMS | 10.88 cm | 7.11 cm | +34.7% |
| WAYPOINTS | 3D RMS | 48.85 cm | 31.92 cm | +34.7% |
| WAYPOINTS | 3D 最大误差 | 88.71 cm | 74.60 cm | +15.9% |

符号说明：RMS 与最大误差为厘米；改善列中负值表示比官方差，正值表示比官方好。

**结论**：

1. 悬停阶段官方位置模式更稳，尤其 Z 轴；MPC 在入稳初期存在明显收敛过程。
2. 航点阶段 MPC 比官方更适合平滑参考轨迹，MPC 的 3D 跟踪 RMS 比官方低约 34.7%。
3. MPC 能完成全部航点并自动降落，求解失败次数为 0。

## 4. MPC 实时性

| 指标 | 数值 |
|---|---:|
| 求解次数 | 1104 |
| 求解平均耗时 | 2.12 ms |
| 求解最大耗时 | 4.60 ms |
| 求解失败 | 0 |
| 速度指令饱和采样数 | 843 / 1104 |
| 加速度 RMS X/Y/Z | 0.98 / 0.93 / 0.64 m/s² |
| 速度估算 RMS | 0.996 m/s |

本机未安装 `osqp`，本次使用内置投影梯度 QP；树莓派安装 `osqp` 后会切换到 OSQP，需要重新测一次求解耗时。

## 5. 过程中的两个实现问题

### 5.1 航点状态机与参考轨迹不同步

原实现用“位置连续 2 秒保持在 0.08 m 内”来推进航点。MPC 参考轨迹在驻留结束时会立刻离开该航点，导致状态机无法推进。已改为根据 `ReferenceTrajectory.completed_segments()` 在参考轨迹每段完成时推进航点。

### 5.2 参考轨迹未使用分轴速度/加速度限制

原轨迹生成器对 X/Y/Z 使用同一组 `vmax/amax`，但 MPC 限幅器对 Z 轴更保守，导致参考轨迹过快、跟踪滞后。现已在 `trajectory_gen.py` 中加入分轴 `vmax_axis/amax_axis`，按各轴约束生成梯形速度轨迹。

## 6. 图表

- `compare/official_vs_mpc_trajectory.png`：XY 路径与统一平滑参考对比。
- `compare/official_vs_mpc_errors.png`：X/Y/Z 跟踪误差时间曲线。
- `compare/official_vs_mpc_rms.png`：分轴 RMS 柱状图。
- `compare/official_vs_mpc_speed.png`：估算速度对比。
- `compare/official_vs_mpc_mpc_metrics.png`：MPC 速度指令、加速度和求解时间。
- `compare/official_vs_mpc_summary.csv`：完整数值汇总。

## 7. 复现命令

```bash
# 官方模式
python3 main.py --config config.json --sim --dry-run --control-mode official \
  --max-flight 60 --log-dir logs/bench_official --tag final-official

# MPC 模式
python3 main.py --config config.json --sim --dry-run --control-mode mpc \
  --max-flight 60 --log-dir logs/bench_mpc --tag final-mpc

# 比较并出图
python3 tools/compare_logs.py \
  --official logs/bench_official/xxx_final-official.csv \
  --mpc logs/bench_mpc/xxx_final-mpc.csv \
  --phase HOVER,WAYPOINTS --config config.json \
  --plot-dir outputs/compare --out outputs/compare/official_vs_mpc_summary.csv
```

## 8. 下一步建议

1. 在树莓派安装 `osqp`，重测 20 Hz 下的真实求解时间和内存占用。
2. 实机先做 `--hover-only` 对比，再跑同一条航点，至少各 3 次。
3.  MPC 悬停 Z 轴入稳偏慢，建议提高 `q_pos[2]`、降低 `r[2]`，或增加 HOVER 前 1 s 的参考速度/加速度平滑。
4. 验证时需要记录电池电压、动捕丢帧、超调、稳定时间和安全事件。
5. 若时间允许，再实现 Tier 2 直接姿态/推力 MPC，才能真正绕过固件位置控制器。
