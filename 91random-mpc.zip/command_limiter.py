# -*- coding: utf-8 -*-
"""Command limiter and anti-saturation accounting for the MPC path."""

import time

import numpy as np


class CommandLimiter:
    def __init__(self, cfg=None):
        c = cfg or {}
        self.vmax_xy = float(c.get("vmax_xy", 0.8))
        self.vmax_z = float(c.get("vmax_z", 0.4))
        self.amax_xy = float(c.get("amax_xy", 1.2))
        self.amax_z = float(c.get("amax_z", 0.8))
        self.jerk_max = float(c.get("jerk_max", 1.2))
        margin = float(c.get("bound_margin_m", 0.15))
        self.x_max = float(c.get("x_max_m", 1.2))
        self.y_max = float(c.get("y_max_m", 1.2))
        self.z_min = float(c.get("z_min_m", 0.05))
        self.z_max = float(c.get("z_max_m", 1.35))
        self.margin = margin
        self._prev_accel = np.zeros(3, dtype=float)
        self._saturated = 0
        self._last_state = None

    def reset(self):
        self._prev_accel[:] = 0.0
        self._saturated = 0
        self._last_state = None

    def limit(self, state, accel, dt, target_pos):
        state = np.asarray(state, dtype=float)
        accel = np.asarray(accel, dtype=float).copy()
        if not np.all(np.isfinite(accel)):
            accel[:] = 0.0
        sat = False
        ax, ay, az = accel
        amax_xy = max(0.05, self.amax_xy)
        amax_z = max(0.05, self.amax_z)
        axc = max(-amax_xy, min(amax_xy, ax))
        ayc = max(-amax_xy, min(amax_xy, ay))
        azc = max(-amax_z, min(amax_z, az))
        a = np.array([axc, ayc, azc], dtype=float)
        sat |= not np.allclose(a, accel)

        dj = self.jerk_max * max(0.001, dt)
        d = a - self._prev_accel
        a = self._prev_accel + np.clip(d, -dj, dj)
        sat |= not np.allclose(a, self._prev_accel + d)

        vel = state[3:6] + a * dt
        vel = np.clip(vel, -self.vmax_xy, self.vmax_xy)
        vel[2] = np.clip(vel[2], -self.vmax_z, self.vmax_z)
        if not np.allclose(vel, state[3:6] + a * dt):
            sat = True
            if dt > 1e-6:
                a = (vel - state[3:6]) / dt
                a = np.clip(a, -amax_xy, amax_xy)
                a[2] = np.clip(a[2], -amax_z, amax_z)

        pos = state[0:3]
        vmax = np.array([self.vmax_xy, self.vmax_xy, self.vmax_z])
        bounds = np.array([self.x_max, self.y_max, self.z_max])
        lower = np.array([-self.x_max, -self.y_max, self.z_min])
        outward_pos = pos >= bounds - self.margin
        outward_neg = pos <= lower + self.margin
        if np.any(outward_pos):
            vel[outward_pos] = np.minimum(vel[outward_pos], 0.0)
            sat = True
        if np.any(outward_neg):
            vel[outward_neg] = np.maximum(vel[outward_neg], 0.0)
            sat = True

        self._prev_accel = a.copy()
        self._last_state = (tuple(pos), tuple(vel))
        if sat:
            self._saturated += 1
        return {
            "accel": tuple(float(v) for v in a),
            "velocity": tuple(float(v) for v in vel),
            "saturated": bool(sat),
            "saturations": self._saturated,
            "dt": dt,
        }

    def snapshot(self):
        return {
            "saturations": self._saturated,
            "last_accel": tuple(float(v) for v in self._prev_accel),
            "last_state": self._last_state,
        }
