# -*- coding: utf-8 -*-
"""Crazyflie link: connection, external pose feeding, estimator reset and radio health."""

import threading
import time

try:
    import cflib.crtp
    from cflib.crazyflie import Crazyflie
    from cflib.crazyflie.log import LogConfig
    HAS_CFLIB = True
except ImportError:
    HAS_CFLIB = False

_STATE_VAR_GROUPS = [
    ("kalman", "stateX", "stateY", "stateZ"),
    ("stateEstimate", "x", "y", "z"),
]
_YAW_VARS = [("stabilizer", "yaw"), ("stateEstimate", "yaw")]
_BATTERY_VARS = [("pm", "vbat")]


class CrazyflieLink:
    def __init__(self, uri, cache_dir="./cache"):
        if not HAS_CFLIB:
            raise RuntimeError("cflib is not installed: pip3 install cflib")
        self.uri = uri
        self.cache_dir = cache_dir
        self._cf = None
        self._connected = threading.Event()
        self._failed = threading.Event()
        self._link_lost = threading.Event()
        self._state = {"x": None, "y": None, "z": None,
                       "yaw_deg": None, "vbat": None}
        self._link_stats = {"link_quality": None, "uplink_rssi": None,
                            "uplink_rate": None, "downlink_rate": None,
                            "uplink_congestion": None,
                            "downlink_congestion": None}
        self._lock = threading.Lock()
        self._lg_state = None
        self._lg_bat = None
        self.actions = []
        self.extpose_mode = "unknown"
        self.extpose_error = ""
        self.last_setpoint_error = ""
        self.link_build = "v2.3"

    def connect(self, timeout=10.0):
        cflib.crtp.init_drivers()
        try:
            self._cf = Crazyflie(rw_cache=self.cache_dir)
        except TypeError:
            self._cf = Crazyflie()

        self._connected.clear()
        self._failed.clear()
        self._link_lost.clear()
        self._cf.connected.add_callback(self._on_connected)
        self._cf.connection_failed.add_callback(self._on_failed)
        self._cf.connection_lost.add_callback(self._on_failed)
        self._cf.disconnected.add_callback(self._on_disconnected)
        try:
            st = self._cf.link_statistics
            st.link_quality_updated.add_callback(self._on_link_quality)
            st.uplink_rssi_updated.add_callback(self._on_uplink_rssi)
            st.uplink_rate_updated.add_callback(self._on_uplink_rate)
            st.downlink_rate_updated.add_callback(self._on_downlink_rate)
        except Exception:
            pass

        self._cf.open_link(self.uri)
        return self._connected.wait(timeout) and not self._failed.is_set()

    def _on_connected(self, uri):
        self._connected.set()

    def _on_failed(self, uri, msg):
        self._failed.set()
        self._link_lost.set()

    def _on_disconnected(self, uri):
        self._connected.clear()
        self._link_lost.set()

    def _on_link_quality(self, value):
        with self._lock:
            self._link_stats["link_quality"] = float(value)

    def _on_uplink_rssi(self, value):
        with self._lock:
            self._link_stats["uplink_rssi"] = float(value)

    def _on_uplink_rate(self, value):
        with self._lock:
            self._link_stats["uplink_rate"] = float(value)

    def _on_downlink_rate(self, value):
        with self._lock:
            self._link_stats["downlink_rate"] = float(value)

    @property
    def cf(self):
        return self._cf

    def link_lost(self):
        return self._link_lost.is_set()

    def get_link_stats(self):
        with self._lock:
            return dict(self._link_stats)

    def arm(self):
        try:
            sup = getattr(self._cf, "supervisor", None)
            if sup is not None and hasattr(sup, "send_arming_request"):
                sup.send_arming_request(True)
                self.actions.append("arming request ON")
                return True
            plat = getattr(self._cf, "platform", None)
            if plat is not None and hasattr(plat, "send_arming_request"):
                plat.send_arming_request(True)
                self.actions.append("arming request ON (platform)")
                return True
        except Exception as exc:
            self.actions.append("arm skip: %s" % exc)
            return False
        self.actions.append("arm skip: supervisor unavailable")
        return False

    def close(self):
        self._stop_logs()
        if self._cf is not None:
            try:
                self._cf.close_link()
            except Exception:
                pass
            self._cf = None

    def _stop_logs(self):
        for lg in (self._lg_state, self._lg_bat):
            if lg is not None:
                try:
                    lg.stop()
                except Exception:
                    pass
        self._lg_state = None
        self._lg_bat = None

    def _param_toc(self):
        return getattr(getattr(self._cf, "param", None), "toc", None)

    def param_exists(self, group, name):
        toc = self._param_toc()
        if toc is None:
            return False
        t = getattr(toc, "toc", {})
        return group in t and name in t[group]

    def try_set_param(self, group, name, value):
        if not self.param_exists(group, name):
            self.actions.append("param skip %s.%s (missing)" % (group, name))
            return False
        self._cf.param.set_value("%s.%s" % (group, name), value)
        self.actions.append("param set %s.%s = %s" % (group, name, value))
        return True

    def get_param(self, group, name, default=None):
        if not self.param_exists(group, name):
            return default
        el = self._param_toc().toc[group][name]
        return el.get_value()

    def setup_for_external_position(self, ext_pos_stddev=0.01,
                                    ext_quat_stddev=0.0045):
        self.actions = []
        self.try_set_param("stabilizer", "estimator", 2)
        self.try_set_param("locSrv", "extPosStdDev", float(ext_pos_stddev))
        self.try_set_param("locSrv", "extQuatStdDev", float(ext_quat_stddev))
        return self.actions

    def reset_ekf(self, x, y, z, yaw_rad=0.0):
        self.try_set_param("kalman", "initialX", float(x))
        self.try_set_param("kalman", "initialY", float(y))
        self.try_set_param("kalman", "initialZ", float(z))
        self.try_set_param("kalman", "initialYaw", float(yaw_rad))
        self.try_set_param("kalman", "resetEstimation", 1)
        time.sleep(0.1)
        self.try_set_param("kalman", "resetEstimation", 0)

    def wait_ekf_convergence(self, timeout_s=20.0):
        if not all(self._log_var_exists("kalman", v)
                   for v in ("varPX", "varPY", "varPZ")):
            self.actions.append("variance log missing, waiting fixed 3s")
            time.sleep(3.0)
            return True

        lg = LogConfig("ekf_var_wait", period_in_ms=100)
        for v in ("varPX", "varPY", "varPZ"):
            lg.add_variable("kalman.%s" % v, "float")
        histories = {"kalman.varPX": [1000.0] * 10,
                     "kalman.varPY": [1000.0] * 10,
                     "kalman.varPZ": [1000.0] * 10}
        done = threading.Event()
        ok = [False]

        def cb(ts, data, logconf):
            for v in histories:
                histories[v].append(float(data[v]))
                histories[v].pop(0)
            if all((max(h) - min(h)) < 0.001 for h in histories.values()):
                ok[0] = True
                done.set()

        self._cf.log.add_config(lg)
        lg.data_received_cb.add_callback(cb)
        lg.start()
        print("[cf] waiting for EKF covariance (timeout %.0fs)..." % timeout_s)
        try:
            done.wait(timeout=timeout_s)
        finally:
            try:
                lg.stop()
            except Exception:
                pass
            try:
                lg.delete()
            except Exception:
                pass
        if ok[0]:
            print("[cf] EKF covariance converged")
        else:
            print("[cf] EKF covariance did NOT converge")
        return ok[0]

    def send_extpos(self, x, y, z):
        if self._can_send():
            self._cf.extpos.send_extpos(x, y, z)
            self.extpose_mode = "extpos"
            return True
        return False

    def send_extpose(self, x, y, z, quat):
        if not self._can_send():
            return False
        self.extpose_error = ""
        try:
            self._cf.extpos.send_extpose(x, y, z, *quat)
            self.extpose_mode = "extpose"
            return True
        except Exception as exc:
            self.extpose_error = repr(exc)
        try:
            self._cf.extpos.send_extpos(x, y, z)
            self.extpose_mode = "extpos_fallback"
            return True
        except Exception as exc:
            self.extpose_error = repr(exc)
            self.extpose_mode = "error"
            return False

    def send_position_setpoint(self, x, y, z, yaw_deg):
        if self._can_send():
            self.last_setpoint_error = ""
            try:
                self._cf.commander.send_position_setpoint(x, y, z, yaw_deg)
            except Exception as exc:
                self.last_setpoint_error = repr(exc)

    def send_velocity_world_setpoint(self, vx, vy, vz, yawrate):
        if self._can_send():
            self._cf.commander.send_velocity_world_setpoint(vx, vy, vz, yawrate)

    def send_attitude_setpoint(self, roll, pitch, yawrate, thrust):
        if self._can_send():
            self._cf.commander.send_setpoint(roll, pitch, yawrate, thrust)

    def send_stop(self):
        if self._can_send():
            self._cf.commander.send_stop_setpoint()
            time.sleep(0.05)
            try:
                self._cf.commander.send_notify_setpoint_stop(0)
            except Exception:
                pass

    def _can_send(self):
        return (self._cf is not None and not self._link_lost.is_set()
                and getattr(self._cf, "link", None) is not None)

    def _log_toc(self):
        return getattr(getattr(self._cf, "log", None), "toc", None)

    def _log_var_exists(self, group, name):
        toc = self._log_toc()
        if toc is None:
            return False
        t = getattr(toc, "toc", {})
        return group in t and name in t[group]

    def _pick_state_vars(self):
        for group, vx, vy, vz in _STATE_VAR_GROUPS:
            if all(self._log_var_exists(group, v) for v in (vx, vy, vz)):
                return ["%s.%s" % (group, v) for v in (vx, vy, vz)]
        return None

    def start_state_log(self, period_ms=100):
        vars_state = self._pick_state_vars()
        if vars_state is None:
            self.actions.append("log skip: no kalman.stateX/Y/Z")
        yaw_var = None
        for g, v in _YAW_VARS:
            if self._log_var_exists(g, v):
                yaw_var = "%s.%s" % (g, v)
                break
        bat_var = None
        for g, v in _BATTERY_VARS:
            if self._log_var_exists(g, v):
                bat_var = "%s.%s" % (g, v)
                break

        def state_cb(ts, data, logconf):
            with self._lock:
                if vars_state:
                    self._state["x"], self._state["y"], self._state["z"] = (
                        data[vars_state[0]], data[vars_state[1]],
                        data[vars_state[2]])
                if yaw_var:
                    self._state["yaw_deg"] = data[yaw_var]

        def bat_cb(ts, data, logconf):
            with self._lock:
                self._state["vbat"] = data[bat_var]

        self._stop_logs()
        if vars_state:
            lg = LogConfig("state", period_in_ms=period_ms)
            for v in vars_state:
                lg.add_variable(v, "float")
            if yaw_var:
                lg.add_variable(yaw_var, "float")
            self._cf.log.add_config(lg)
            lg.data_received_cb.add_callback(state_cb)
            lg.start()
            self._lg_state = lg
            self.actions.append("log start %dms: %s" % (period_ms, vars_state))
        if bat_var:
            lg = LogConfig("battery", period_in_ms=500)
            lg.add_variable(bat_var, "float")
            self._cf.log.add_config(lg)
            lg.data_received_cb.add_callback(bat_cb)
            lg.start()
            self._lg_bat = lg
            self.actions.append("log start: %s" % bat_var)

    def get_state(self):
        with self._lock:
            return dict(self._state)


class ExtposFeeder:
    """Mocap thread: transform frames and feed external pose to Crazyflie."""

    def __init__(self, source, transform, safety, link=None, rate_hz=20.0,
                 use_extpose=True, state_estimator=None):
        self._source = source
        self._transform = transform
        self._safety = safety
        self._link = link
        self._state_estimator = state_estimator
        self.rate_hz = rate_hz
        self.use_extpose = use_extpose
        self._stop = threading.Event()
        self._thread = None
        self._lock = threading.Lock()
        self.last_frame = None
        self.last_raw = None
        self.last_pose = None
        self.send_errors = 0
        self.send_success = 0
        self.last_send_ts = None
        self.last_send_mode = ""
        self.last_send_error = ""

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def _run(self):
        period = 1.0 / max(1.0, self.rate_hz)
        last_sent = 0.0
        while not self._stop.is_set():
            frame = self._source.latest_frame()
            now = time.time()
            if frame is None:
                time.sleep(0.002)
                continue
            with self._lock:
                self.last_frame = frame
                self.last_raw = (frame.x_mm, frame.y_mm, frame.z_mm,
                                 frame.yaw_deg)

            pose = None
            quat = (0.0, 0.0, 0.0, 1.0)
            yaw_deg = 0.0
            if frame.valid():
                t = self._transform.apply(frame)
                pose = (t["x"], t["y"], t["z"])
                yaw_deg = t["yaw_deg"]
                quat = t.get("quaternion", (0.0, 0.0, 0.0, 1.0))
                with self._lock:
                    self.last_pose = (pose, yaw_deg, quat)
            self._safety.on_frame(now, pose, yaw_deg, frame.frame_no)
            if pose is not None and self._state_estimator is not None:
                self._state_estimator.update(frame, pose, yaw_deg)

            if pose is not None and self._link is not None:
                if now - last_sent >= period:
                    try:
                        if self.use_extpose and hasattr(self._link, "send_extpose"):
                            ok = self._link.send_extpose(*pose, quat)
                            mode = getattr(self._link, "extpose_mode", "unknown")
                        elif hasattr(self._link, "send_extpos"):
                            ok = self._link.send_extpos(*pose)
                            if ok is None:
                                ok = True
                            mode = getattr(self._link, "extpose_mode", "unknown")
                        else:
                            ok = False
                            mode = "unavailable"
                        with self._lock:
                            if ok:
                                self.send_success += 1
                                self.last_send_ts = now
                                self.last_send_mode = mode
                                self.last_send_error = ""
                            else:
                                self.send_errors += 1
                                self.last_send_mode = mode
                                self.last_send_error = getattr(
                                    self._link, "extpose_error", "unknown")
                    except Exception as exc:
                        with self._lock:
                            self.send_errors += 1
                            self.last_send_error = repr(exc)
                    last_sent = now

    def snapshot(self):
        with self._lock:
            state = None
            if self._state_estimator is not None:
                state = self._state_estimator.snapshot()
            return {"last_frame_no": self.last_frame.frame_no
                    if self.last_frame else None,
                    "last_raw": self.last_raw,
                    "last_pose": self.last_pose,
                    "send_success": self.send_success,
                    "send_errors": self.send_errors,
                    "last_send_ts": self.last_send_ts,
                    "last_send_mode": self.last_send_mode,
                    "last_send_error": self.last_send_error,
                    "last_send_age_s": (round(time.time() - self.last_send_ts, 3)
                                        if self.last_send_ts else None),
                    "state": state}


class FakeLink:
    """Dry-run link with a simple simulated position integrator."""

    def __init__(self, verbose=False, target_sink=None):
        self.verbose = verbose
        self._target_sink = target_sink
        self._sim_pos = [0.0, 0.0, 0.0]
        self._sim_t = None
        self.last_setpoint = None
        self.last_setpoint_error = ""
        self.actions = []
        self._link_stats = {"link_quality": 100.0}

    def setup_for_external_position(self, *a, **k):
        return ["fake: skip params"]

    def reset_ekf(self, x, y, z):
        self.actions.append("fake: reset_ekf (%.2f,%.2f,%.2f)" % (x, y, z))

    def arm(self):
        self.actions.append("fake: arm")
        return True

    def link_lost(self):
        return False

    def get_link_stats(self):
        return dict(self._link_stats)

    def send_extpos(self, x, y, z):
        self.actions.append("fake: extpos (%.3f, %.3f, %.3f)" % (x, y, z))

    def send_extpose(self, x, y, z, quat):
        self.actions.append("fake: extpose (%.3f, %.3f, %.3f)" % (x, y, z))

    def send_position_setpoint(self, x, y, z, yaw_deg):
        self.last_setpoint = (x, y, z, yaw_deg)
        self._sim_pos = [x, y, z]
        if self._target_sink is not None:
            self._target_sink(x, y, z)
        if self.verbose:
            print("  setpoint -> (%.3f, %.3f, %.3f, yaw %.1f)"
                  % (x, y, z, yaw_deg))

    def send_attitude_setpoint(self, roll, pitch, yawrate, thrust):
        self.actions.append("fake: attitude %s" % ((roll, pitch, yawrate, thrust),))

    def send_velocity_world_setpoint(self, vx, vy, vz, yawrate):
        now = time.time()
        if self._sim_t is None:
            self._sim_t = now
            dt = 0.02
        else:
            dt = min(0.2, max(0.001, now - self._sim_t))
            self._sim_t = now
        self._sim_pos[0] += vx * dt
        self._sim_pos[1] += vy * dt
        self._sim_pos[2] = max(0.0, self._sim_pos[2] + vz * dt)
        self.last_setpoint = (self._sim_pos[0], self._sim_pos[1],
                              self._sim_pos[2], 0.0)
        if self._target_sink is not None:
            self._target_sink(*self._sim_pos)
        if self.verbose:
            print("  vel -> (%.3f, %.3f, %.3f, yawrate %.1f)"
                  % (vx, vy, vz, yawrate))

    def send_stop(self):
        self.actions.append("fake: STOP")

    def get_state(self):
        return {"x": None, "y": None, "z": None, "yaw_deg": None,
                "vbat": None}

    def close(self):
        pass
