# -*- coding: utf-8 -*-
"""Translation MPC for the Crazyflie host loop.

State: [px, py, pz, vx, vy, vz]
Input: [ax, ay, az]
The controller solves a finite-horizon convex QP. OSQP is used when it is
installed; otherwise a lightweight projected-gradient solver is used with
acceleration box constraints. Velocity and jerk limits are enforced by the
CommandLimiter, which keeps the fallback path safe even without a third-party
solver.
"""

import time

import numpy as np

from command_limiter import CommandLimiter

try:
    import osqp
    import scipy.sparse as sp
    _HAS_OSQP = True
except Exception:
    osqp = None
    sp = None
    _HAS_OSQP = False


class TranslationMPC:
    def __init__(self, cfg=None):
        c = cfg or {}
        self.N = max(2, int(c.get("horizon", 12)))
        self.dt = float(c.get("dt", 0.05))
        self.max_iters = int(c.get("max_iterations", 250))
        self.tol = float(c.get("tol", 1e-5))
        self.amax_xy = float(c.get("amax_xy", 1.2))
        self.amax_z = float(c.get("amax_z", 0.8))
        self.vmax_xy = float(c.get("vmax_xy", 0.8))
        self.vmax_z = float(c.get("vmax_z", 0.4))
        self.jerk_max = float(c.get("jerk_max", 1.2))
        if c.get("q_pos"):
            qp = np.diag(c["q_pos"])
            qv = np.diag(c.get("q_vel", [1.2, 1.2, 1.5]))
        else:
            qp = np.diag([8.0, 8.0, 12.0])
            qv = np.diag([1.2, 1.2, 1.5])
        self.Q = np.block([[qp, np.zeros((3, 3))],
                           [np.zeros((3, 3)), qv]])
        self.R = np.diag(c.get("r", [0.12, 0.12, 0.18]))
        self.S = np.diag(c.get("s", [0.35, 0.35, 0.45]))
        self._last_u = np.zeros(self.N * 3, dtype=float)
        self._last_solve_ms = 0.0
        self._last_cost = 0.0
        self.failures = 0
        self.solves = 0
        self._build_matrices()

    def _build_matrices(self):
        N, dt = self.N, self.dt
        A = np.eye(6, dtype=float)
        A[0:3, 3:6] = np.eye(3) * dt
        B = np.zeros((6, 3), dtype=float)
        B[0:3, 0:3] = np.eye(3) * 0.5 * dt * dt
        B[3:6, 0:3] = np.eye(3) * dt
        self.A = A
        self.B = B
        self.S_x = np.vstack([np.linalg.matrix_power(A, i + 1)
                              for i in range(N)])
        self.S_u = np.zeros((6 * N, 3 * N), dtype=float)
        for k in range(N):
            for j in range(k, N):
                self.S_u[6 * j:6 * j + 6, 3 * k:3 * k + 3] = (
                    np.linalg.matrix_power(A, j - k) @ B)
        self.Qbig = np.kron(np.eye(N), self.Q)
        self.Rbig = np.kron(np.eye(N), self.R)
        self.Sbig = np.kron(np.eye(N), self.S)
        self.D = np.zeros((3 * N, 3 * N), dtype=float)
        for k in range(N):
            self.D[3 * k:3 * k + 3, 3 * k:3 * k + 3] = np.eye(3)
            if k > 0:
                self.D[3 * k:3 * k + 3, 3 * (k - 1):3 * k] = -np.eye(3)
        self.P = (self.S_u.T @ self.Qbig @ self.S_u
                  + self.Rbig + self.D.T @ self.Sbig @ self.D)
        self.umin = np.tile([-self.amax_xy, -self.amax_xy, -self.amax_z], N)
        self.umax = np.tile([self.amax_xy, self.amax_xy, self.amax_z], N)

    def reset(self):
        self._last_u[:] = 0.0
        self.failures = 0
        self.solves = 0

    def _ref_stack(self, state, reference_fn, t0):
        N, dt = self.N, self.dt
        if reference_fn is None:
            pos = state[0:3]
            vel = state[3:6]
            r = np.concatenate((pos, vel))
            return np.tile(r, N)
        rows = []
        for i in range(N):
            pos, vel, _acc = reference_fn(t0 + dt * (i + 1))
            rows.append(np.concatenate((pos, vel)))
        return np.concatenate(rows)

    def _build_q(self, x0, r_stack, prev_accel):
        q = 2.0 * (self.S_u.T @ self.Qbig @ (self.S_x @ x0 - r_stack))
        e = np.zeros(self.N * 3, dtype=float)
        e[0:3] = np.asarray(prev_accel, dtype=float)[0:3]
        q += -2.0 * (self.D.T @ self.Sbig @ e)
        return q

    def _projected_solve(self, x0, r_stack, q, prev_accel):
        N = self.N
        u = np.zeros(3 * N, dtype=float)
        pnorm = np.linalg.norm(self.P, ord=2)
        alpha = min(0.1, 1.0 / max(1e-6, pnorm))
        u_next = u.copy()
        for _ in range(self.max_iters):
            grad = self.P @ u + q
            u_next = np.clip(u - alpha * grad, self.umin, self.umax)
            if np.linalg.norm(u_next - u) < self.tol * max(1.0, np.linalg.norm(u)):
                u = u_next
                break
            u = u_next
        self._last_u = u.copy()
        x1 = self.A @ x0 + self.B @ u[0:3]
        return x1, u

    def _osqp_solve(self, x0, r_stack, q, prev_accel):
        N, dt = self.N, self.dt
        eye = sp.eye(3 * N, format="csc")
        V = sp.csc_matrix(self.S_u[3:6:6, :])
        D = sp.csc_matrix(self.D)
        x0v = self.S_x[3:6:6, :] @ x0
        vlim = np.maximum(np.tile([self.vmax_xy, self.vmax_xy, self.vmax_z], N),
                          np.abs(x0v))
        jerk = np.tile([self.jerk_max * dt] * 3, N)
        e = np.zeros(3 * N, dtype=float)
        e[0:3] = np.asarray(prev_accel, dtype=float)[0:3]
        A = sp.vstack([eye, V, -V, D, -D], format="csc")
        l = np.concatenate([self.umin,
                            -np.inf * np.ones(3 * N),
                            -np.inf * np.ones(3 * N),
                            -np.inf * np.ones(3 * N),
                            -np.inf * np.ones(3 * N)])
        u_lim = np.concatenate([self.umax,
                                vlim - x0v,
                                vlim + x0v,
                                e + jerk,
                                -e + jerk])
        prob = osqp.OSQP()
        prob.setup(P=sp.csc_matrix(self.P), q=q, A=A, l=l, u=u_lim,
                   verbose=False, eps_abs=1e-4, eps_rel=1e-4,
                   warm_start=True)
        sol = prob.solve()
        u = np.asarray(sol.x, dtype=float)
        if not np.all(np.isfinite(u)):
            raise RuntimeError("osqp returned non-finite solution")
        self._last_u = u.copy()
        x1 = self.A @ x0 + self.B @ u[0:3]
        return x1, u

    def solve(self, state, reference_fn=None, t0=0.0, prev_accel=(0.0, 0.0, 0.0)):
        state = np.asarray(state, dtype=float)
        t_start = time.time()
        r_stack = self._ref_stack(state, reference_fn, t0)
        q = self._build_q(state, r_stack, prev_accel)
        try:
            if _HAS_OSQP:
                x1, u = self._osqp_solve(state, r_stack, q, prev_accel)
                backend = "osqp"
            else:
                x1, u = self._projected_solve(state, r_stack, q, prev_accel)
                backend = "projected"
            failed = not np.all(np.isfinite(x1))
            if failed:
                self.failures += 1
        except Exception:
            self.failures += 1
            failed = True
            backend = "fallback"
            u = np.zeros(3 * self.N, dtype=float)
            x1 = self.A @ state + self.B @ u[0:3]
        self.solves += 1
        self._last_solve_ms = (time.time() - t_start) * 1000.0
        self._last_cost = float(u @ (self.P @ u) + q @ u)
        return {
            "accel": tuple(float(v) for v in u[0:3]),
            "velocity": tuple(float(v) for v in x1[3:6]),
            "predict_pos": tuple(float(v) for v in x1[0:3]),
            "solve_ms": self._last_solve_ms,
            "cost": self._last_cost,
            "failed": failed,
            "backend": backend,
        }

    @staticmethod
    def make_limiter(cfg=None):
        return CommandLimiter(cfg)
