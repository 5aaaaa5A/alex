# -*- coding: utf-8 -*-
"""Flight state machine and setpoint generation."""

import math
import threading
import time

from command_limiter import CommandLimiter
from mpc_controller import TranslationMPC
from trajectory_gen import ReferenceTrajectory


class FlightController:
    def __init__(self, link, safety, feeder, cfg, logger=None, waypoints=None,
                 battery_provider=None, flight_enabled=False,
                 state_estimator=None, control_mode="official"):
        self.link = link
        self.safety = safety
        self.feeder = feeder
        self.logger = logger
        self.battery_provider = battery_provider
        self.flight_enabled = bool(flight_enabled)
        self.state_estimator = state_estimator
        self.control_mode = control_mode
        base_rate = float(cfg.get("setpoint_rate_hz", 10.0))
        mpc_rate = float(cfg.get("control", {}).get("rate_hz", base_rate))
        mpc_cfg = dict(cfg.get("mpc", {}))
        mpc_cfg["dt"] = 1.0 / max(1.0, mpc_rate)
        self.mpc = TranslationMPC(mpc_cfg) if control_mode == "mpc" else None
        self.limiter = (CommandLimiter(mpc_cfg)
                        if control_mode == "mpc" else None)
        self.trajectory = None
        self._traj_start = None
        self._last_mpc = {}
        self._last_ref = None
        self.cfg = cfg
        s = cfg["safety"]
        self.takeoff_z = float(cfg["takeoff_z"])
        self.hover_z = float(cfg.get("hover_z", cfg["takeoff_z"]))
        self.max_altitude_m = float(cfg.get("max_altitude_m",
                                            self.hover_z + 0.45))
        self.hover_hold_s = float(cfg.get("hover_hold_s", 5.0))
        self.waypoints = waypoints if waypoints is not None else cfg.get("waypoints", [])
        self.hover_only = bool(cfg.get("hover_only", False))
        self.takeoff_ramp_s = float(s["takeoff_ramp_s"])
        self.takeoff_ready_z_m = float(s.get("takeoff_ready_z_m", 0.30))
        self.takeoff_max_s = float(s.get("takeoff_max_s", 6.0))
        self.climb_ramp_s = float(s.get("climb_ramp_s", 4.0))
        self.climb_ready_z_m = float(s.get("climb_ready_z_m", 0.90))
        self.climb_max_s = float(s.get("climb_max_s", 6.0))
        self.landing_ramp_s = float(s["landing_ramp_s"])
        self.landing_z_m = float(s["landing_z_m"])
        self.arrive_m = float(s["waypoint_arrive_m"])
        self.setpoint_rate_hz = mpc_rate if control_mode == "mpc" else base_rate

        self.state = "IDLE"
        self.done = False
        self.last_status = "OK"
        self.last_row = {}
        self.stop_reason = ""

        self._x0 = self._y0 = 0.0
        self._t_state = 0.0
        self._t_prev = 0.0
        self._wp_idx = 0
        self._wp_hold_start = None
        self._land_x = self._land_y = 0.0
        self._land_z_from = 0.0
        self._stop_t = None
        self._setpoint = (0.0, 0.0, 0.0, 0.0)
        self._pid_fallback_logged = False

        self.land_requested = threading.Event()
        self.estop_requested = threading.Event()
        self._stop = threading.Event()

    def run(self, max_flight_s=None):
        period = 1.0 / max(1.0, self.setpoint_rate_hz)
        next_t = time.time()
        t0 = time.time()
        while not self._stop.is_set():
            now = time.time()
            if hasattr(self.link, "link_lost") and self.link.link_lost():
                self.estop_requested.set()

            if self.battery_provider is not None:
                try:
                    v = self.battery_provider().get("vbat")
                    if v is not None:
                        self.safety.set_battery(float(v))
                except Exception:
                    pass

            if self.estop_requested.is_set():
                self._goto(now, "STOP", "manual estop")
            elif (self.land_requested.is_set()
                    and self.state not in ("LAND", "STOP")):
                self._goto(now, "LAND", "manual land")

            status, pose = self.safety.evaluate(now)
            self.last_status = status

            if self.flight_enabled and self.feeder is not None:
                ep = self.feeder.snapshot()
                if (ep.get("send_errors", 0) > 0
                        or ep.get("last_send_mode") == "error"):
                    self._goto(now, "STOP", "extpose send failure")
                elif (ep.get("last_send_age_s") is not None
                      and ep["last_send_age_s"] > 0.5):
                    self._goto(now, "STOP", "extpose feed timeout")

            if status == "ESTOP":
                if self.state != "STOP":
                    self._goto(now, "STOP", "safety ESTOP")
            elif status == "LAND":
                if self.state not in ("LAND", "STOP"):
                    self._goto(now, "LAND", "safety LAND")
            elif status == "HOLD" and self.state not in ("LAND", "STOP"):
                pass

            if status == "HOLD" and self.state not in ("LAND", "STOP"):
                sp = self._setpoint
            else:
                sp = self._tick(now, status, pose)
                self._setpoint = sp

            self._send(now, sp, pose, status)

            if self.logger is not None:
                self.last_row = self._build_row(now, t0, status, pose, sp)
                self.logger.write(self.last_row)

            if self.done:
                break
            if max_flight_s and now - t0 > max_flight_s:
                self.land_requested.set()

            next_t += period
            delay = next_t - time.time()
            if delay > 0:
                time.sleep(delay)

    def stop(self):
        self._stop.set()

    def _goto(self, now, state, reason):
        if self.state == state:
            return
        self.stop_reason = reason
        self._t_state = now
        if state == "LAND":
            sx, sy, sz, _ = self._setpoint
            self._land_x, self._land_y = sx, sy
            self._land_z_from = sz
            self.safety.set_fence_active(False)
            self.safety.set_airborne(False)
        elif state == "STOP":
            self.safety.set_fence_active(False)
            self.safety.set_airborne(False)
        elif state == "WAYPOINTS" and self.control_mode == "mpc" and self.mpc is not None:
            pose = self.safety.get_pose()
            self.trajectory = ReferenceTrajectory(
                self.waypoints,
                vmax=self.mpc.vmax_xy,
                amax=self.mpc.amax_xy,
                vmax_axis=(self.mpc.vmax_xy, self.mpc.vmax_xy,
                           self.mpc.vmax_z),
                amax_axis=(self.mpc.amax_xy, self.mpc.amax_xy,
                           self.mpc.amax_z))
            self.trajectory.start(pose)
            self._traj_start = now
            self.mpc.reset()
            if self.limiter is not None:
                self.limiter.reset()
        self.state = state
        print("[state] -> %s (%s)" % (state, reason))

    def _tick(self, now, status, pose):
        px, py, pz = pose

        if (status == "OK" and self.state in ("TAKEOFF", "CLIMB", "HOVER",
                                              "WAYPOINTS")
                and pz > self.max_altitude_m):
            self._goto(now, "LAND", "altitude runaway")
            return self._setpoint

        if self.state == "IDLE":
            if status == "OK":
                self._x0, self._y0 = px, py
                self._goto(now, "UNLOCK", "mocap ready")
            return self._setpoint

        if self.state == "UNLOCK":
            if now - self._t_state >= 1.0:
                self._goto(now, "TAKEOFF", "unlock done")
            return self._setpoint

        if self.state == "TAKEOFF":
            if pz >= self.takeoff_ready_z_m or now - self._t_state >= self.takeoff_ramp_s:
                if self.flight_enabled:
                    self.safety.set_airborne(True)
                    self.safety.set_fence_active(True)
                self._goto(now, "CLIMB", "takeoff done")
                return (self._x0, self._y0, self.takeoff_z, 0.0)
            if now - self._t_state >= self.takeoff_max_s:
                self._goto(now, "LAND", "takeoff timeout")
                return self._setpoint
            z = max(0.0, min(self.takeoff_z, pz))
            return (self._x0, self._y0, z, 0.0)

        if self.state == "CLIMB":
            if pz >= self.climb_ready_z_m or now - self._t_state >= self.climb_ramp_s:
                self._goto(now, "HOVER", "climb done")
                return (self._x0, self._y0, self.hover_z, 0.0)
            if now - self._t_state >= self.climb_max_s:
                self._goto(now, "LAND", "climb timeout")
                return self._setpoint
            return (self._x0, self._y0, self.hover_z, 0.0)

        if self.state == "HOVER":
            if now - self._t_state >= self.hover_hold_s:
                if self.hover_only or not self.waypoints or not self.flight_enabled:
                    self._goto(now, "LAND", "hover done")
                else:
                    self._wp_idx = 0
                    self._wp_hold_start = None
                    self._goto(now, "WAYPOINTS", "start mission")
            return (self._x0, self._y0, self.hover_z, 0.0)

        if self.state == "WAYPOINTS":
            if self._wp_idx >= len(self.waypoints):
                self._goto(now, "LAND", "mission done")
                return self._setpoint
            if (self.control_mode == "mpc" and self.trajectory is not None
                    and self._traj_start is not None):
                t_plan = max(0.0, now - self._traj_start)
                completed = self.trajectory.completed_segments(t_plan)
                self._wp_idx = max(self._wp_idx,
                                   min(completed, len(self.waypoints)))
                if self._wp_idx >= len(self.waypoints):
                    self._goto(now, "LAND", "mission done")
                    return self._setpoint
            wp = self.waypoints[self._wp_idx]
            dist = math.hypot(px - wp["x"], py - wp["y"])
            if dist <= self.arrive_m:
                if self._wp_hold_start is None:
                    self._wp_hold_start = now
                elif now - self._wp_hold_start >= wp.get("hold_s", 0.0):
                    self._wp_idx += 1
                    self._wp_hold_start = None
                    print("[wp] reach #%d %s" % (self._wp_idx - 1, wp))
            else:
                self._wp_hold_start = None
            return (wp["x"], wp["y"], wp["z"], wp.get("yaw_deg", 0.0))

        if self.state == "LAND":
            frac = min(1.0, (now - self._t_state) / self.landing_ramp_s)
            z = self._land_z_from + frac * (self.landing_z_m - self._land_z_from)
            if pz < self.landing_z_m + 0.06 and now - self._t_state > 1.0:
                self._goto(now, "STOP", "landed")
                return self._setpoint
            return (self._land_x, self._land_y, z, 0.0)

        if self.state == "STOP":
            if self._stop_t is None:
                self._stop_t = now
                self.link.send_stop()
            if now - self._stop_t >= 0.5:
                self.done = True
            return self._setpoint

        return self._setpoint

    def _sample_reference(self, t):
        if self.trajectory is None:
            return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
        return self.trajectory.sample(t)

    def _send_mpc(self, now, sp, pose):
        if self.mpc is None:
            self.link.send_position_setpoint(*sp)
            return
        state = None
        if self.state_estimator is not None:
            snap = self.state_estimator.snapshot()
            if snap.get("ready"):
                state = tuple(snap["pos"]) + tuple(snap["vel"])
        if state is None:
            self.link.send_position_setpoint(*sp)
            return
        if self.trajectory is not None and self._traj_start is not None:
            t0 = now - self._traj_start
            ref_fn = self._sample_reference
        else:
            t0 = 0.0
            ref_fn = None
        ref_pos = tuple(sp[0:3])
        ref_vel = (0.0, 0.0, 0.0)
        ref_acc = (0.0, 0.0, 0.0)
        if ref_fn is not None:
            ref_pos, ref_vel, ref_acc = ref_fn(t0)
        else:
            ref_fn = lambda _t: (ref_pos, ref_vel, ref_acc)
        prev_accel = self._last_mpc.get("accel", (0.0, 0.0, 0.0))
        res = self.mpc.solve(state, ref_fn, t0, prev_accel=prev_accel)
        if res["failed"]:
            kp = 1.2
            kd = 0.5
            fallback_acc = tuple(
                (ref_vel[i] - state[3 + i]) / max(1e-3, self.mpc.dt)
                + kp * (ref_pos[i] - state[i])
                + kd * (ref_vel[i] - state[3 + i])
                for i in range(3))
            if self.limiter is not None:
                lim = self.limiter.limit(state, fallback_acc, self.mpc.dt, ref_pos)
                vel_cmd = lim["velocity"]
                sat = lim["saturated"]
            else:
                vel_cmd = tuple(res["velocity"])
                sat = False
            self.link.send_velocity_world_setpoint(*vel_cmd, 0.0)
            self._last_mpc = {
                "mode": "mpc_fallback",
                "accel": fallback_acc,
                "velocity": vel_cmd,
                "state": state,
                "ref_pos": ref_pos,
                "ref_vel": ref_vel,
                "ref_acc": ref_acc,
                "solve_ms": res["solve_ms"],
                "cost": res["cost"],
                "failed": True,
                "backend": res["backend"],
                "saturated": sat,
            }
            return
        if self.limiter is not None:
            lim = self.limiter.limit(state, res["accel"], self.mpc.dt, ref_pos)
            vel_cmd = lim["velocity"]
            sat = lim["saturated"]
        else:
            vel_cmd = tuple(res["velocity"])
            sat = False
        self.link.send_velocity_world_setpoint(*vel_cmd, 0.0)
        self._last_mpc = {
            "mode": "mpc",
            "accel": res["accel"],
            "velocity": vel_cmd,
            "state": state,
            "ref_pos": ref_pos,
            "ref_vel": ref_vel,
            "ref_acc": ref_acc,
            "solve_ms": res["solve_ms"],
            "cost": res["cost"],
            "failed": False,
            "backend": res["backend"],
            "saturated": sat,
        }

    def _send(self, now, sp, pose, status="OK"):
        if self.state == "UNLOCK":
            self.link.send_attitude_setpoint(0.0, 0.0, 0.0, 0)
        elif self.state in ("TAKEOFF", "CLIMB"):
            pz = pose[2] if pose is not None else 0.0
            target_z = self.takeoff_z if self.state == "TAKEOFF" else self.hover_z
            vz = max(0.0, min(0.25, (target_z - pz) / 1.5))
            self.link.send_velocity_world_setpoint(0.0, 0.0, vz, 0.0)
        elif self.state == "STOP":
            pass
        else:
            if (status == "OK" and self.mpc is not None
                    and self.state in ("HOVER", "WAYPOINTS")):
                self._send_mpc(now, sp, pose)
                return
            sp_err = getattr(self.link, "last_setpoint_error", "")
            if sp_err:
                px, py, pz = pose if pose is not None else (0.0, 0.0, 0.0)
                k = 1.0
                vx = max(-0.2, min(0.2, (sp[0] - px) * k))
                vy = max(-0.2, min(0.2, (sp[1] - py) * k))
                vz = max(-0.2, min(0.2, (sp[2] - pz) * k))
                if not self._pid_fallback_logged:
                    print("[ctrl] position setpoint failed (%s), "
                          "fallback to velocity PID" % sp_err)
                    self._pid_fallback_logged = True
                self.link.send_velocity_world_setpoint(vx, vy, vz, 0.0)
            else:
                self.link.send_position_setpoint(*sp)

    def _build_row(self, now, t0, status, pose, sp):
        ex, ey, ez = pose
        sx, sy, sz, syaw = sp
        raw = {"frame_no": None, "raw": None}
        if self.feeder is not None:
            raw["frame_no"] = getattr(self.feeder.last_frame, "frame_no", None)
            raw["raw"] = self.feeder.last_raw
        ekf = getattr(self.link, "get_state", lambda: {})()
        stats = getattr(self.link, "get_link_stats", lambda: {})()
        snap = self.safety.snapshot()
        ep = self.feeder.snapshot() if self.feeder is not None else {}
        try:
            events = list(self.safety.events)[-3:]
        except RuntimeError:
            events = []
        exf, eyf, ezf = (ekf.get("x"), ekf.get("y"), ekf.get("z"))
        ekf_err = ""
        if None not in (exf, eyf, ezf):
            ekf_err = round(math.sqrt((exf-ex)**2 + (eyf-ey)**2 + (ezf-ez)**2), 4)
        est = ep.get("state") or {}
        mpc = self._last_mpc or {}
        est_pos = est.get("pos", (None, None, None))
        est_vel = est.get("vel", (None, None, None))
        ref_pos = mpc.get("ref_pos", (None, None, None))
        ref_vel = mpc.get("ref_vel", (None, None, None))
        mpc_acc = mpc.get("accel", (None, None, None))
        mpc_vel = mpc.get("velocity", (None, None, None))
        mpc_state = mpc.get("state", (None, None, None, None, None, None))
        return {
            "ctrl_mode": mpc.get("mode", self.control_mode),
            "t_s": round(now - t0, 3),
            "frame_no": raw["frame_no"] or "",
            "mocap_ts": "",
            "latency": "",
            "raw_x_mm": raw["raw"][0] if raw["raw"] else "",
            "raw_y_mm": raw["raw"][1] if raw["raw"] else "",
            "raw_z_mm": raw["raw"][2] if raw["raw"] else "",
            "raw_yaw_deg": raw["raw"][3] if raw["raw"] else "",
            "pos_x": round(ex, 4), "pos_y": round(ey, 4),
            "pos_z": round(ez, 4),
            "pos_yaw_deg": round(self.safety.get_yaw(), 2),
            "set_x": round(sx, 4), "set_y": round(sy, 4),
            "set_z": round(sz, 4), "set_yaw_deg": round(syaw, 2),
            "err_x": round(ex - sx, 4), "err_y": round(ey - sy, 4),
            "err_z": round(ez - sz, 4),
            "ekf_x": round(exf, 4) if exf is not None else "",
            "ekf_y": round(eyf, 4) if eyf is not None else "",
            "ekf_z": round(ezf, 4) if ezf is not None else "",
            "ekf_err": ekf_err,
            "state_x": round(est_pos[0], 4) if est_pos[0] is not None else "",
            "state_y": round(est_pos[1], 4) if est_pos[1] is not None else "",
            "state_z": round(est_pos[2], 4) if est_pos[2] is not None else "",
            "state_vx": round(est_vel[0], 4) if est_vel[0] is not None else "",
            "state_vy": round(est_vel[1], 4) if est_vel[1] is not None else "",
            "state_vz": round(est_vel[2], 4) if est_vel[2] is not None else "",
            "state_vel_source": est.get("vel_source", ""),
            "ref_x": round(ref_pos[0], 4) if ref_pos[0] is not None else "",
            "ref_y": round(ref_pos[1], 4) if ref_pos[1] is not None else "",
            "ref_z": round(ref_pos[2], 4) if ref_pos[2] is not None else "",
            "ref_vx": round(ref_vel[0], 4) if ref_vel[0] is not None else "",
            "ref_vy": round(ref_vel[1], 4) if ref_vel[1] is not None else "",
            "ref_vz": round(ref_vel[2], 4) if ref_vel[2] is not None else "",
            "mpc_ax": round(mpc_acc[0], 4) if mpc_acc[0] is not None else "",
            "mpc_ay": round(mpc_acc[1], 4) if mpc_acc[1] is not None else "",
            "mpc_az": round(mpc_acc[2], 4) if mpc_acc[2] is not None else "",
            "cmd_vx": round(mpc_vel[0], 4) if mpc_vel[0] is not None else "",
            "cmd_vy": round(mpc_vel[1], 4) if mpc_vel[1] is not None else "",
            "cmd_vz": round(mpc_vel[2], 4) if mpc_vel[2] is not None else "",
            "mpc_state_x": round(mpc_state[0], 4) if mpc_state[0] is not None else "",
            "mpc_state_y": round(mpc_state[1], 4) if mpc_state[1] is not None else "",
            "mpc_state_z": round(mpc_state[2], 4) if mpc_state[2] is not None else "",
            "mpc_solve_ms": round(mpc.get("solve_ms", 0.0), 3),
            "mpc_cost": round(mpc.get("cost", 0.0), 4),
            "mpc_backend": mpc.get("backend", ""),
            "mpc_fails": self.mpc.failures if self.mpc is not None else 0,
            "cmd_saturated": 1 if mpc.get("saturated") else 0,
            "link_quality": stats.get("link_quality", ""),
            "uplink_rssi": stats.get("uplink_rssi", ""),
            "extpose_mode": ep.get("last_send_mode", ""),
            "extpose_sent": ep.get("send_success", ""),
            "extpose_errors": ep.get("send_errors", ""),
            "battery_v": (round(snap["battery_v"], 3)
                          if snap["battery_v"] is not None else ""),
            "status": "%s/%s" % (status, self.state),
            "age_valid_s": snap["age_valid_s"],
            "events": " | ".join(m for _, m in events[-3:]),
        }
