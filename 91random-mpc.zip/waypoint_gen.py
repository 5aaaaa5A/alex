"""轨迹/航点生成：矩形、直线插值、圆形（用于轨迹飞行实验）。"""

import math


def rectangle(size_m, z_m, yaw_deg=0.0, hold_s=2.0, per_side=3):
    """正方形航点（含回到起点的闭合轨迹）。"""
    pts = [
        (0.0, 0.0), (size_m, 0.0), (size_m, size_m), (0.0, size_m),
    ]
    dense = []
    for i in range(len(pts)):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % len(pts)]
        for j in range(per_side):
            a = j / per_side
            dense.append({"x": x0 + (x1 - x0) * a,
                          "y": y0 + (y1 - y0) * a,
                          "z": z_m, "yaw_deg": yaw_deg, "hold_s": 0.0})
    dense.append({"x": 0.0, "y": 0.0, "z": z_m, "yaw_deg": yaw_deg,
                  "hold_s": hold_s})
    return dense


def circle(cx, cy, r_m, z_m, n=24, yaw_deg=0.0, hold_s=0.0):
    """圆形轨迹（逆时针）。"""
    return [
        {"x": cx + r_m * math.cos(2 * math.pi * i / n),
         "y": cy + r_m * math.sin(2 * math.pi * i / n),
         "z": z_m, "yaw_deg": yaw_deg, "hold_s": hold_s}
        for i in range(n)
    ]


def interpolate(p0, p1, n=10):
    """两航点间直线插值。"""
    return [{"x": p0["x"] + (p1["x"] - p0["x"]) * i / n,
             "y": p0["y"] + (p1["y"] - p0["y"]) * i / n,
             "z": p0["z"] + (p1["z"] - p0["z"]) * i / n,
             "yaw_deg": p1.get("yaw_deg", 0.0), "hold_s": 0.0}
            for i in range(1, n + 1)]
